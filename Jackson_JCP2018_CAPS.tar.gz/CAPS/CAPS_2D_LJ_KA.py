from CAPS_2D_LJ_def import *

step_arr = [1000,5,256]
pot_arr = [['exact',5.0],[1.11,2.0],[1.12,2.0]]
#pot_arr = [['exact',2.0],[0.9,2.0],[0.95,2.0],[1.0,2.0]]

#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
#Kob-Anderson parameters: epsAA=1.0,sigAA=1.0,epsAB=1.5,sigAB=0.8,epsBB=0.5,sigBB=0.88
mysim = Sim(step_arr,pot_arr,10.5,60,30,1.0,1.0,0.5,0.88)
#append 'final_save.xyz' at the end of the Sim call to load in pre-equilibrated geometry
#Defaults to arithmetic/geometric mixing, so must set cross-terms directly
#for i in range(mysim.num_layers):
#    mysim.layers[i].xy = np.copy(mysim.xy)
mysim.plot_all_potentials()

mysim.params.max_disp = 0.1
mysim.params.beta = 1.0
mysim.run_CAPS_LJ(0)
mysim.print_acc_ratio()
mysim.print_pot_calls()
print "Average energy/particle: "+str(np.mean(np.array(mysim.layers[0].E_list))/256.0)


fix,ax = plt.subplots(2,1)
ax[0].plot(mysim.layers[0].E_list)
ax[0].set_ylim(min(mysim.layers[0].E_list),0.0)
mysim.write_xyz(0,'final.xyz')
mysim.compute_RDF(0)
ax[1].plot(mysim.r_arr,mysim.r_hist)
ax[1].axhline(y=1.0,color='r',linestyle='-')
ax[1].set_xlim(0.0,3.0)
plt.show()
