#from CAPS_2D_LJ_def_idiotic import *
from CAPS_2D_LJ_def_simple import *

step_arr = [100000,2,128]
pot_arr = [['exact',2.5],['exact',2.4],['exact',2.3]]

#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
#Kob-Anderson parameters: epsAA=1.0,sigAA=1.0,epsAB=1.5,sigAB=0.8,epsBB=0.5,sigBB=0.88
mysim = Sim(step_arr,pot_arr,29.2118697,256,0,1.0,1.0,0.5,0.88,'final.xyz')
#25.2982213 is box length to use for high dens (0.4) results
#29.2119 is box length to use for results data
#22.627417 for 0.5 density
#ADD FINAL.XYZ TO THE END OF THIS TO LOAD IN AN EQUILIBRATED FILE
#append 'final_save.xyz' at the end of the Sim call to load in pre-equilibrated geometry
#Defaults to arithmetic/geometric mixing, so must set cross-terms directly
mysim.params.beta = 1.11111


#print 'running simulation'
mysim.run_CAPS_LJ(0)
#print 'simulation over'

exact = -0.873

MC_1layer = np.array(mysim.layers[0].E_list)
MC_1layer = np.cumsum(MC_1layer)
norm_1layer = np.arange(1,len(MC_1layer)+1,1)
MC_1layer = ((np.divide(MC_1layer,norm_1layer)/mysim.params.Ntot)-exact)/exact
MC_1_pot_calls = np.array(mysim.layers[0].pot_call_list)
#print(MC_1_pot_calls)

with open('E_vs_n.txt','w') as f:
    for i in range(len(norm_1layer)):
        f.write("{} \t {} \n".format(norm_1layer[i],MC_1layer[i]))

"""
del mysim
step_arr = [10000,2,2,64]
pot_arr = [['exact',2.5],['exact',1.8],['exact',1.6],['exact',1.3]]
mysim = Sim(step_arr,pot_arr,29.2119,256,0,1.0,1.0,0.5,0.88,'final.xyz')
mysim.run_CAPS_LJ(0)
MC_2layer = np.array(mysim.layers[0].E_list)
MC_2layer = np.cumsum(MC_2layer)
norm_2layer = np.arange(1,len(MC_2layer)+1,1)
MC_2layer = ((np.divide(MC_2layer,norm_2layer)/mysim.params.Ntot)-exact)/exact
MC_2_pot_calls = np.array(mysim.layers[0].pot_call_list)

print(MC_1layer[:-1]+' for 1 layer')
print(MC_2layer[:-1]+' for 4 layer')
#print(MC_2_pot_calls)
plt.plot(norm_1layer,MC_1layer,label='1 layer')
plt.plot(norm_2layer,MC_2layer,label='2 layer')
plt.xscale('log')
plt.ylim(-0.1,0.1)
plt.legend()
plt.show()
"""
#plot_hist_1 = np.array(mysim.layers[0].E_list)
#results_1,edges_1 = np.histogram(plot_hist_1, bins=50, normed=True)

#RDF = mysim.RDF_track
#RDF_mean = np.mean(RDF,axis=0)
#r_ax = mysim.RDF_arr
#ax[1].plot(r_ax,RDF_mean,label='CAPS')
#ax[1].axhline(y=1.0,color='r',linestyle='-')
#ax[1].set_xlim(0.0,3.0)
#mysim.write_RDF_file("RDF.txt")
#exact_x,exact_y = mysim.read_RDF_file("exact_1layer_RDF.txt")
#ax[1].plot(exact_x,exact_y,label='1layer exact')
#ax[1].legend()
#plt.show()
