#include <boost/python.hpp>
#include <boost/shared_ptr.hpp>
namespace py = boost::python;

BOOST_PYTHON_MODULE(Sim) {
	export_my_thing();
}
