#include <stdio.h>
#include "basic_2D.h"
#include <boost/python.hpp>
namespace py = boost::python;
/*
int main()
{
  particle_list sim_list;

  sim_list = particle_list(10);
  sim_list.print_part();
}*/

void export_my_thing () {
	py::class_<atom>("atom")
.def_readwrite("type", &atom::type)	
.def_readwrite("x", &atom::x)	
.def_readwrite("y", &atom::y)	
.def("print_xy", &atom::print_xy)	
.def("print_type", &atom::print_type)	
;
}

