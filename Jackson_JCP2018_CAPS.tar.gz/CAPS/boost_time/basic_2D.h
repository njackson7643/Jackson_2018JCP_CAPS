#include <vector>
#include <iostream>

class atom {
public:
  //double xy[2];
double x;
double y;
  int type;
  
  atom(){}
  atom(int t, double x_, double y_) {
    type = t;
    x = x_;
    y = y_;
  }

  void print_type(){
    std::cout << "type: " << type << std::endl;
  }

  void print_xy(){
    std::cout << "x: " << x << " y: " << y << std::endl;
  }
};

/*
class particle_list {
 public:
  std::vector<atom> particles;
  int num_part;
  particle_list(){}
  particle_list(int n) {
    particles = std::vector<atom>(n,atom(0,0.0,0.0));
    num_part = n;
  }

  void print_part(){
    for(int i=0; i < num_part; i++){
      particles[i].print_type();
      particles[i].print_xy();
    }
  }
};
  */
