import os
import numpy as np
import sys

num_part = 10
num_MC_steps = 5

xy_arr = np.zeros( (num_part,2) , dtype = zeros)

for i in range(num_MC_steps):
    #metropolis_function


