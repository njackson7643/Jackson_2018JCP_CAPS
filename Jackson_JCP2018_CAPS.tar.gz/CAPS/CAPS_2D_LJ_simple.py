from CAPS_2D_LJ_def_simple import *


step_arr = [10**6.]
#step_arr = [10,256]
pot_arr = [['exact',2.5],['exact',2.0]]
#pot_arr = [['exact',2.5],[0.93,2.5],[0.97,2.5],[1.01,2.5]]

#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
#Kob-Anderson parameters: epsAA=1.0,sigAA=1.0,epsAB=1.5,sigAB=0.8,epsBB=0.5,sigBB=0.88
mysim = Sim(step_arr,pot_arr,29.2119,256,0,1.0,1.0,0.5,0.88)
#25.2982213 is box length to use for high dens (0.4) results
#29.2119 is box length to use for results data
#ADD FINAL.XYZ TO THE END OF THIS TO LOAD IN AN EQUILIBRATED FILE
#append 'final_save.xyz' at the end of the Sim call to load in pre-equilibrated geometry
#Defaults to arithmetic/geometric mixing, so must set cross-terms directly
#mysim.plot_all_potentials()
#sys.exit()
mysim.params.beta = 1.11111


#print 'running simulation'
mysim.run_CAPS_LJ(0)
#print 'simulation over'

plot_hist_1 = np.array(mysim.layers[0].E_list)
results_1,edges_1 = np.histogram(plot_hist_1, bins=50, normed=True)

"""
del mysim
step_arr = [16*10**5,4,4]
pot_arr = [['exact',2.5],['exact',2.2],['exact',2.0]]
mysim = Sim(step_arr,pot_arr,6.3,16,0,1.0,1.0,0.5,0.88,'final.xyz')
mysim.params.beta = 1.11111
mysim.run_CAPS_LJ(0)

plot_hist_2 = np.array(mysim.layers[0].E_list)
results_2,edges_2 = np.histogram(plot_hist_2, bins=50, normed=True)

#binWidth = np.max([edges_1[0],edges_1[1],edges_2[0],edges_2[1]]) - np.min([edges_1[0],edges_1[1],edges_2[0],edges_2[1]])


binWidth=edges_1[1]-edges_1[0]
plt.bar(edges_1[:-1], results_1*binWidth, binWidth,label='1layer',alpha=0.5)
plt.bar(edges_2[:-1], results_2*binWidth, binWidth,label='3layer',alpha=0.5)
plt.legend()
plt.show()


mysim.print_acc_ratio()
mysim.print_pot_calls()
#print "Average energy/particle: "+str(np.mean(np.array(mysim.layers[0].E_list))/256.0)
#mysim.write_xyz(0,'final.xyz')


fig,ax = plt.subplots(2,1)
ax[0].plot(mysim.layers[0].E_list)
ax[0].set_ylim(min(mysim.layers[0].E_list),0.0)
plt.show()
"""
#RDF = mysim.RDF_track
#RDF_mean = np.mean(RDF,axis=0)
#r_ax = mysim.RDF_arr
#ax[1].plot(r_ax,RDF_mean,label='CAPS')
#ax[1].axhline(y=1.0,color='r',linestyle='-')
#ax[1].set_xlim(0.0,3.0)
#mysim.write_RDF_file("RDF.txt")
#exact_x,exact_y = mysim.read_RDF_file("exact_1layer_RDF.txt")
#ax[1].plot(exact_x,exact_y,label='1layer exact')
#ax[1].legend()
#plt.show()
