import pes2Dgauss as pes
import numpy as np
from random import random
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import math
import sys

class MidpointNormalize(colors.Normalize):
    """                                                                                                                 
    Normalise the colorbar so that diverging bars work there way either side from a prescribed midpoint value)          
                                                                                                                        
    e.g. im=ax1.imshow(array, norm=MidpointNormalize(midpoint=0.,vmin=-100, vmax=100))                                  
    """
    def __init__(self, vmin=None, vmax=None, midpoint=None, clip=False):
        self.midpoint = midpoint
        colors.Normalize.__init__(self, vmin, vmax, clip)

    def __call__(self, value, clip=None):
    # I'm ignoring masked values and all kinds of edge cases to make a                                                  
    # simple example...                                                                                                 
        x, y = [self.vmin, self.midpoint, self.vmax], [0, 0.5, 1]
        return np.ma.masked_array(np.interp(value, x, y), np.isnan(value))


def importPES(the_pes):
    globals()['pes'] = the_pes

#Function that proposes a trial move in x
def trial_move(xy_arr,max_disp):
    test_disp_x = max_disp*(random()-0.5)
    test_disp_y = max_disp*(random()-0.5)
    xt = xy_arr[0] + test_disp_x
    yt = xy_arr[1] + test_disp_y
    return xt,yt

#Class for a given layer of the CAPS MC - Has own unique level number, number of MC steps, and potential value
class Layer:
    def __init__(self,num,steps,pot):
        self.layer_num = num                          #Layer number
        self.nsteps = steps                           #Number of MC steps within that layer
        self.coeffs = pes.load_coeffs()                                #coefficients to generate 2d surface
        self.xys = np.array([0.2,0.2])                                 #Variable to hold saved coordinate
        self.xyt = np.array([0.2,0.2])                                 #Variable to hold trial coordinate
        self.max_disp = 0.3                                            #Maximum random displacement
        self.pot = pot                                #Controls height of barriers in each layer
        self.pot_calls = 0
        self.Es = self.pot*pes.evaluate(0.0,self.xys,*self.coeffs)         #Variable to hold potential for xys
#        print('Starting Es: ',self.Es)
        self.Et = 0.0                                 #Variable to hold potential for xyt
        self.beta = 1.0                               #Beta temperature param for MC accept
        self.xys_hist = []                             #Array to hold all visited configurations in this layer
        self.att_count = 0                            #Keep track of attempted MC moves in this layer
        self.acc_count = 0                            #Keep track of accepted MC moves in this layer

    #Method to run a basic Metropolis MC routine within the layer
    def metropolis(self):
#        print('running metropolis in lowest layer')
#        print('before move')
#        print('xys: ',self.xys)
#        print('Es: ',self.Es)
        self.att_count += 1
        self.xyt = trial_move(self.xys,self.max_disp)
        self.Et = self.pot*pes.evaluate(0.0,self.xyt,*self.coeffs)
        self.pot_calls += 1
        x,y = self.xyt
#        print('after move')
#        print('xyt: ',self.xyt)
#        print('Et: ',self.Et)
        if self.Et < self.Es:
            self.Es = self.Et
            self.xys = self.xyt
            self.acc_count += 1
#            self.xys_hist.append(self.xys)
#            print('xys: ',self.xys)
#            print('xyt: ',self.xyt)
#            print('Es: ',self.Es)
#            print('Et: ',self.Et)
#            print('accept, Et < Es')
        else:
            rand_n = random()
            prob = math.exp(-self.beta*(self.Et-self.Es))
            if rand_n < prob:
                self.Es = self.Et
                self.xys = self.xyt 
                self.acc_count += 1
#                self.xys_hist.append(self.xys)
#                print('xys: ',self.xys)
#                print('xyt: ',self.xyt)
#                print('Es: ',self.Es)
#                print('Et: ',self.Et)
#                print('accept, rand:  ',rand_n,' prob: ',prob)
            else:
                self.Et = self.Es
#                self.xys_hist.append(self.xys)
#                print('xys: ',self.xys)
#                print('xyt: ',self.xyt)
#                print('Es: ',self.Es)
#                print('Et: ',self.Et)
#                print('reject')

#Class that holds all MC layers of the simulation
class Sim:
    def __init__(self,steps_arr,pot_arr):
        if len(steps_arr) != len(pot_arr):
            print('Layer input is incorrect, exiting...')
            sys.exit()
        else:
            self.coeffs = pes.load_coeffs()
            self.steps_arr = steps_arr
            self.count = 0.0
            self.pot_arr = pot_arr
            self.num_layers = len(steps_arr)
            self.first_layer = 0
            self.last_layer = self.num_layers-1
            self.layers = []
            self.hist_disc = 100
            self.E_mean = 0.0
            self.low_bound = 0.0
            self.hi_bound = 1.0
            self.disc = (self.hi_bound-self.low_bound)/float(self.hist_disc)
            self.shift = int(abs(self.low_bound)/self.disc)
            self.FEP_FES_surf = np.zeros( (self.hist_disc,self.hist_disc) , dtype = float)
            self.FEP_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            self.count_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            self.FEP_count_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            for i in range(self.num_layers):
                self.layers.append(Layer(i,steps_arr[i],pot_arr[i]))

    #Method that performs the deltaE1-deltaE0 check between MC layers of simulation        

    def update_count(self,level):
        x,y = self.layers[level].xys
        xbin = int(x/self.disc) + self.shift
        ybin = int(y/self.disc) + self.shift
        self.count_hist[level,xbin,ybin] += 1.0

    def metropolis_2(self,level):
#        print('checking between layers',level,level-1)
        beta = 1.0
        self.layers[level-1].att_count += 1.0
        E_xf_n1 = self.layers[level].Es
        E_xi_n1 = self.layers[level].pot*pes.evaluate(0.0,self.layers[level-1].xys,*self.coeffs)
        E_xf_n0 = self.layers[level-1].pot*pes.evaluate(0.0,self.layers[level].xys,*self.coeffs)
        E_xi_n0 = self.layers[level-1].Es
        self.layers[level].pot_calls += 1
        self.layers[level-1].pot_calls += 1
        deltaE0 = E_xf_n0-E_xi_n0
        deltaE1 = E_xf_n1-E_xi_n1
#        print('status before check:\n')
#        print('level ',level-1,' xy: ',self.layers[level-1].xys)
#        print('level ',level,' xy: ',self.layers[level].xys)
#        print('E_xf_n1: ',E_xf_n1)
#        print('E_xi_n1: ',E_xi_n1)
#        print('E_xf_n0: ',E_xf_n0)
#        print('E_xi_n0: ',E_xi_n0)
#        print('deltaE0: ',deltaE0)
#        print('deltaE1: ',deltaE1)
        rand_num = random()
        x,y = self.layers[level].xys
        xbin = int(x/self.disc) + self.shift
        ybin = int(y/self.disc) + self.shift
        #DO FREE ENERGY PERTURBATION CHECK
        self.FEP_hist[level-1,xbin,ybin] += math.exp(-beta*(E_xf_n0-E_xf_n1))
        self.FEP_count_hist[level-1,xbin,ybin] += 1.0
        prob = math.exp(-beta*(deltaE0-deltaE1))
#        print('status after check:\n')
        if rand_num < prob:
            self.layers[level-1].acc_count += 1
            self.layers[level-1].Es = E_xf_n0
            self.layers[level].Es = E_xf_n1
            self.layers[level-1].xys = np.copy(self.layers[level].xys)
            self.update_count(level-1)
#            self.layers[level-1].xys_hist.append(self.layers[level-1].xys)
#            self.layers[level].xys_hist.append(self.layers[level].xys)
#            print('level ',level-1,' xy: ',self.layers[level-1].xys)
#            print('level ',level,' xy: ',self.layers[level].xys)
#            print('level ',level-1,' Es: ',self.layers[level-1].Es)
#            print('level ',level-1,' Et: ',self.layers[level-1].Et)
#            print('level ',level,' Es: ',self.layers[level].Es)
#            print('level ',level,' Et: ',self.layers[level].Et)
#            print('accept')
        else:
            self.layers[level-1].Es = E_xi_n0
            self.layers[level].Es = E_xi_n1
            self.layers[level].xys = np.copy(self.layers[level-1].xys)
            self.update_count(level-1)
#            self.layers[level-1].xys_hist.append(self.layers[level-1].xys)
#            self.layers[level].xys_hist.append(self.layers[level].xys)
#            print('level ',level-1,' xy: ',self.layers[level-1].xys)
#            print('level ',level,' xy: ',self.layers[level].xys)
#            print('level ',level-1,' Es: ',self.layers[level-1].Es)
#            print('level ',level-1,' Et: ',self.layers[level-1].Et)
#            print('level ',level,' Es: ',self.layers[level].Es)
#            print('level ',level,' Et: ',self.layers[level].Et)
#            print('reject')

    #Recursive method that runs an arbitrary number of nested loops.  This is where the meat is.
    def run_CAPS(self,level):
        if level == 0 and self.last_layer == 0:
            for j in range(self.layers[level].nsteps):                
                self.layers[level].xys_hist.append(self.layers[level].xys)
                x,y = self.layers[level].xys
                xbin = int(x/self.disc) + self.shift
                ybin = int(y/self.disc) + self.shift
                beta = 1.0
                self.FEP_hist[level,xbin,ybin] += math.exp(-beta*self.layers[level].Es)
                self.FEP_count_hist[level,xbin,ybin] += 1.0
                if j%1 == 0:
                    self.count += 1.0
                    self.E_mean += self.layers[level].Es
                if j%1000 == 0:
                    print(j,self.E_mean/self.count)
                self.layers[level].metropolis()            
        elif level == 0 and level != self.last_layer:
#            self.layers[level].xys_hist.append(self.layers[level].xys)
            self.layers[level+1].xys = np.copy(self.layers[level].xys)
            for i in range(self.layers[level].nsteps):
                self.count += 1.0
                self.E_mean += self.layers[level].Es
                if i%1000 == 0:
                    print(i,self.E_mean/self.count,self.layers[level].xys)
                self.run_CAPS(level+1)
#                self.layers[level].xys_hist.append(self.layers[level].xys)
        elif level != 0 and level != self.last_layer:
#            self.layers[level].xys_hist.append(self.layers[level].xys)
            self.layers[level+1].xys = np.copy(self.layers[level].xys)
            for k in range(self.layers[level].nsteps):
                self.run_CAPS(level+1)
#                self.layers[level].xys_hist.append(self.layers[level].xys)
            self.metropolis_2(level)
        elif level == self.last_layer:
#            self.layers[level].xys_hist.append(self.layers[level].xys)
            for r in range(self.layers[level].nsteps):                
                self.layers[level].metropolis()
#                self.layers[level].xys_hist.append(self.layers[level].xys)
                x,y = self.layers[level].xys
#                self.layers[level].xys_hist.append(self.layers[level].xys)
                xbin = int(x/self.disc) + self.shift
                ybin = int(y/self.disc) + self.shift
                beta = 1.0
                self.FEP_hist[level,xbin,ybin] += math.exp(-beta*self.layers[level].Es)
                self.FEP_count_hist[level,xbin,ybin] += 1.0
                self.update_count(level)
            self.metropolis_2(level)

    def print_pot_calls(self):
        sum = 0
        for layer in self.layers:
            sum += layer.pot_calls
            print("Potential calls in layer "+str(layer.pot_calls))
        print("Total potential calls in CAPS simulation: "+str(sum))
        return sum

    def print_acc_ratio(self):
        for layer in self.layers:
            print("Acceptance ratio in layer "+str(layer.layer_num)+": "+str((layer.acc_count)/float(layer.att_count)))

    def gen_count_FES_surfaces(self):
        self.count_surfaces = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
        self.FES_surfaces = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
        for i in range(self.num_layers):
            self.count_surfaces[i] = self.count_hist[i]/np.sum(self.count_hist[i])
            self.FES_surfaces[i] = -1.*np.log(self.count_surfaces[i])

    def gen_FEP_surface(self):
        self.FEP_hist2 = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
        self.FEP_FES_surf = np.zeros( (self.hist_disc,self.hist_disc) , dtype = float)
        for i in range(self.num_layers):
            self.FEP_hist2[i] = np.copy(np.divide(self.FEP_hist[i],self.FEP_count_hist[i]))
            self.FEP_hist2[i] = -1.*np.log(self.FEP_hist2[i])
        self.FEP_FES_surf = np.nansum(self.FEP_hist2,axis=0)

    def calc_probability_surf(self):
        beta = 1.0
        self.prob_hist = np.copy(self.FEP_FES_surf)
#        self.prob_hist += np.min(self.prob_hist)
        self.prob_hist = np.exp(-1.*beta*self.prob_hist)
        norm_const = np.sum(self.prob_hist)*self.disc*self.disc
        self.prob_hist /= norm_const
#        print(self.prob_hist)
#        print(np.sum(self.prob_hist))
        
    def read_exact_prob_surf(self,filename):
        self.exact_prob_hist = np.zeros( (self.hist_disc,self.hist_disc) , dtype = float)
        with open(filename,'r') as f:
            for i,line in enumerate(f):
                if i > 0:
                    templine = line.split()
                    x = float(templine[0])
                    y = float(templine[1])
                    xbin = int(x/self.disc)
                    ybin = int(y/self.disc)
                    prob = float(templine[2])
                    self.exact_prob_hist[xbin,ybin] = prob
#        print(self.exact_prob_hist)
#        print(np.sum(self.exact_prob_hist))
