import os
import math
import numpy as np
import sys
from sys import argv
import matplotlib.pyplot as plt

script, trajfile = argv

dr = 0.05
rcut = 5.0
rcut2 = rcut*rcut
boxl = 29.2
r_hist = np.zeros( int(rcut/dr)+1 , dtype = float)
r_arr = np.arange(0,rcut+dr,dr , dtype = float)
Ntot = 256
tsteps = 100

coords = np.zeros( (tsteps,Ntot,2) , dtype = float) 

step_count = -1
atom_count = -1
with open(trajfile,'r') as f:
    for i,line in enumerate(f):
        templine = line.split()
        if len(templine) == 1:
            step_count += 1
            atom_count = 0
        if len(templine) == 4:
            id = atom_count
            x = float(templine[1])
            y = float(templine[2])
            coords[step_count,atom_count,0] = x
            coords[step_count,atom_count,1] = y
            atom_count += 1
        if step_count >= tsteps:
            break

for snap in range(tsteps):
    config = coords[snap]
    for i in range(Ntot):
        x1 = config[i,0]
        y1 = config[i,1]
        for j in range(i+1,Ntot):
            x2 = config[j,0]
            y2 = config[j,1]
            dx = x2-x1
            dy = y2-y1
            if dx > boxl/2.:
                dx -= boxl
            elif dx < -boxl/2.:
                dx += boxl
            if dy > boxl/2.:
                dy -= boxl
            elif dy < -boxl/2.:
                dy += boxl
            r2 = dx*dx + dy*dy
            if r2 < rcut2:
                r = math.sqrt(r2)
                rbin = int(r/dr)
                r_hist[rbin] += 2


r_hist /= float(tsteps)
r_hist *= float(boxl)*float(boxl)
r_hist /= float(Ntot)*float(Ntot)

for i in range(len(r_hist)):
    norm = 2.*3.14159*r_arr[i]*dr
    r_hist[i] /= norm

plt.plot(r_arr,r_hist)
plt.xlim(0.0,3.0)
plt.show()
