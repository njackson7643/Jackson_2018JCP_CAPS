#==================================================================
# SUPPORTING MODULES
#==================================================================
import numpy as np

#==================================================================
# CONSTANTS VARIABLES
#==================================================================
main="pes.main_nejedit.dat"	# coefficient file name for main Guassians
supp="pes.supp.dat"	# coefficient file name for supplemental Gaussians

#==================================================================
#  AUX: isnumber
#==================================================================
def isnumber(s):
  try:
    float(s)
    return True
  except ValueError:
    return False

#==================================================================
#  AUX: numericalize
#==================================================================
def numericalize(fid):
  lines = [line.strip().split() for line in fid]
  lines = [line for line in lines if isnumber(line[0])]
  data = [[float(s) for s in line] for line in lines] # extract numerical       data
  return np.array(data)

#==================================================================
#  AUX: load_coeffs
#==================================================================
def load_coeffs():
  coeffs = []
  for fid in [open(main,"r"),open(supp,"r")]:
    c = numericalize(fid)
    coeffs.append(c.transpose())
  return coeffs

#==================================================================
#  AUX: evaluate
#==================================================================
def evaluate(Er,r,cmain,csupp):
  x   = r[0]		# x-coordinate
  y   = r[1]		# y-coordinate
  A   = cmain[0,:]	# amplitudes of main gaussians
  x0  = cmain[1,:]	# x-centers for main gaussians
  y0  = cmain[2,:]	# y-centers for main gaussians
  sx  = cmain[3,:]	# x-widths for main gaussians
  sy  = cmain[4,:]	# y-widths for main gaussians
  As  = csupp[0,:]	# amplitudes of supp gaussians
  x0s = csupp[1,:]	# x-centers for supp gaussians
  y0s = csupp[2,:]	# y-centers for supp gaussians
  sxs = csupp[3,:]	# x-widths for supp gaussians
  sys = csupp[4,:]	# y-widths for supp gaussians
  Umain = A  * np.exp(-0.5*( (x-x0 )**2/sx**2  + (y-y0 )**2/sy**2  ) )
  Usupp = As * np.exp(-0.5*( (x-x0s)**2/sxs**2 + (y-y0s)**2/sys**2 ) )
  Ubase = np.sum(Umain) + np.sum(Usupp) - Er
  if (0.0 <= x <= 1.0) and (0.0 <= y <= 1.0):
    return Ubase
  if ( x<= 0.0):
    Ubase += 100000.0
#      Ubase += 2000.0*(x)**2.0
  if ( x>= 1.0):
    Ubase += 100000.0
#      Ubase += 2000.0*(x-1.)**2.0
  if ( y<= 0.0):
    Ubase += 100000.0
#      Ubase += 2000.0*(y)**2.0
  if ( y>= 1.0):
    Ubase += 100000.0
#      Ubase += 2000.0*(y-1.)**2.0
  return Ubase


