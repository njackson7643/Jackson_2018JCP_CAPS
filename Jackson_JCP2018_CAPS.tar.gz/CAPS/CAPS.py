from CAPS_2D_def import *

#Parameters for simulation
#step array takes the form [n0steps,n1steps,n2steps,...]
#pot array takes the form [potn0,potn1,potn2,...]
step_arr = [100]
pot_arr = [9.0]

#Run Simulation
mysim = Sim(step_arr,pot_arr)
mysim.run_CAPS(0)
mysim.print_acc_ratio()
print "Simulation Finished"

#Analyze/Plot Simulation results
xmin = -5.0
xmax = 5.0
dx = 0.1
ax = np.arange(xmin,xmax,dx)
plot_ax = np.arange(xmin+dx/2.,xmax-dx/2,dx)
#construct hist
fig,ax1 = plt.subplots()

c_cycle = ['b','g','r','c','m','y','k','w']

for i in range(mysim.num_layers):
    myhist = np.histogram(np.array(mysim.layers[i].xs_hist),bins=ax)[0]
    myhist = myhist/float(mysim.layers[i].att_count)
    ax1.bar(plot_ax,myhist,dx,alpha=0.2,color=c_cycle[i],label=str(i)+': '+str(mysim.layers[i].pot))
    ax1.set_ylabel('Probability')
    ax1.set_xlabel('Position (x)')
ax1.legend()

ax2 = ax1.twinx()
ax2.plot(ax,potential(pot_arr[0],ax),'r-',label='PES',linewidth=3.0)
ax2.set_ylim(-pot_arr[0]/(4.*minC),2)
ax2.set_ylabel('Potential')
ax2.set_title("CAPS Sampling")
plt.show()
