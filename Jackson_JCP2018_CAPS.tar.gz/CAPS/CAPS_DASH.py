import CAPS_def_DASH


import sys
sys.append(dash path)
from DASH import *
#Parameters for simulation
#step array takes the form [n0steps,n1steps,n2steps,...]
#pot array takes the form [potn0,potn1,potn2,...]


#first we're going to build the layers.



def setPotential0(state):
    potential = FixLJCut(state, 'cut')
    potential.setParameter('sig', 'spc1', 'spc1', 1)
    potential.setParameter('eps', 'spc1', 'spc1', 1)
    state.activateFix(potential)

def setPotential1(state):
    potential = FixLJCut(state, 'cut')
    potential.setParameter('sig', 'spc1', 'spc1', 1)
    potential.setParameter('eps', 'spc1', 'spc1', 0.5) #or whatever
    state.rCut = 2.0 #I could also set rCut
    state.activateFix(potential)


def setPotential2(state):
    potential = FixLJCut(state, 'cut')
    potential.setParameter('sig', 'spc1', 'spc1', 1)
    potential.setParameter('eps', 'spc1', 'spc1', 0.25) #or whatever
    state.rCut = 1.5
    state.activateFix(potential)


def buildState(atomPositions, setPotential):
    temp = 1.2


    state = State()
    state.bounds = Bounds(state, lo=Vector(0, 0, 0), hi=Vector(50, 50, 50))
    state.rCut=3.0
    state.padding=0.6
    state.atomParams.addSpecies(handle='spc1', mass=1, atomicNum=1)
    setPotential(state)
    for pos in atomPositions:
        state.addAtom('spc1', pos)
    fixNVT = FixNoseHoover(state, 'nvt', 'all')
    fixNVT.setTemperature(temp, 100*state.dt)
    state.activateFix(fixNVT)

    InitializeAtoms.initTemp(state, 'all', temp)

    integrator = IntegratorVerlet(state)

    state.helpers = {'temp': temp, 'integrator': integrator}
    return [state]






initPositions = [Vector(1,2,3), Vector(4,5,6)]#... or I could load from a file

states = [buildState(initPositions, p) for p in [setPotential0, setPotential1, setPotential2]]

step_arr = [100,100,100]

#Run Simulation
mysim = Sim(step_arr, states)
mysim.run_CAPS(0)
mysim.print_acc_ratio()
print "Simulation Finished"

#Analyze/Plot Simulation results
xmin = -5.0
xmax = 5.0
dx = 0.1
ax = np.arange(xmin,xmax,dx)
plot_ax = np.arange(xmin+dx/2.,xmax-dx/2,dx)
#construct hist
fig,ax1 = plt.subplots()

c_cycle = ['b','g','r','c','m','y','k','w']

for i in range(mysim.num_layers):
#mysim.num_layers):
    myhist = np.histogram(np.array(mysim.layers[i].xs_hist),bins=ax)[0]
    myhist = myhist/float(mysim.layers[i].att_count)
    ax1.bar(plot_ax,myhist,dx,alpha=0.2,color=c_cycle[i],label=str(i)+': '+str(mysim.layers[i].pot))
    ax1.set_ylabel('Probability')
    ax1.set_xlabel('Position (x)')
ax1.legend()

ax2 = ax1.twinx()
ax2.plot(ax,potential(pot_arr[0],ax),'r-',label='PES',linewidth=3.0)
ax2.set_ylim(-pot_arr[0]/(4.*minC),2)
ax2.set_ylabel('Potential')
ax2.set_title("CAPS Sampling")
plt.show()
