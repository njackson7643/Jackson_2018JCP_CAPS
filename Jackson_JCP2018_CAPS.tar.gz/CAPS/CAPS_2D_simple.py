from CAPS_2D_def_simple import *
import sys
import pickle
sys.path = sys.path + ['/Users/nick/Box\ Sync/Work/CAPS/Rough2D']
from matplotlib import cm
#from mpl_toolkits.axes_grid1 import make_axes_locatable
import pes2Dgauss as pes
importPES(pes)

#@profile
def main():
    #Parameters for simulation
    #step array takes the form [n0steps,n1steps,n2steps,...]
    #pot array takes the form [potn0,potn1,potn2,...]
    #pot_arr now takes factors by which to scale the energy (<1)
    print('\n\n STARTING CAPS RUN ON 2D SURFACE \n\n')

    step_arr = [10**6,10,10]
    pot_arr = [1.0,0.5,0.2]
    E_base = -19.63872
    RMSE_base = 9.21909

    #Run Simulation
    print('Running a CAPS simulation with ')
    print('step profile: ',step_arr,)
    print('and potential profile: ',pot_arr)
    mysim = Sim(step_arr,pot_arr)
    pot_call_list = []
    RMSE_list = []
    E_list = []
    for i in range(1):
        mysim.run_CAPS(0)
        mysim.print_acc_ratio()
        pot_calls = mysim.print_pot_calls()
        ave_E = mysim.E_mean/mysim.count
        print("average energy: ",str(ave_E))
        mysim.gen_count_FES_surfaces()
        mysim.gen_FEP_surface()
        mysim.calc_probability_surf()
        mysim.read_exact_prob_surf('probs_1.0.dat')

        diff = np.subtract(mysim.exact_prob_hist,mysim.prob_hist)
        square_diff = np.square(diff)
        MSE = np.sum(square_diff)/float(mysim.hist_disc**2.)
        RMSE = math.sqrt(MSE)

        pot_call_list.append(pot_calls)
        E_list.append((ave_E-E_base)/E_base)
        RMSE_list.append((RMSE/RMSE_base))
        print('<E> error: ',100.0*(ave_E-E_base)/E_base,'%')
        print('RMSE: ',RMSE/RMSE_base)
#        plt.imshow(mysim.prob_hist,origin='lower')
#        plt.show()

    
    FEP_scale = mysim.FEP_FES_surf
    FEP_scale -= np.min(FEP_scale)

    exact_FES = np.copy(mysim.exact_prob_hist)
    exact_FES /= np.sum(exact_FES)
    exact_FES = -1.*np.log(exact_FES)
    exact_FES -= np.min(exact_FES)

    FES0 = mysim.FES_surfaces[0]-np.min(mysim.FES_surfaces[0])

    diff = exact_FES-FEP_scale

#    pickle.dump( FEP_scale, open("Figure_A.p","wb"))
#    pickle.dump( FES0, open("Figure_B.p","wb"))
#    pickle.dump( exact_FES, open("Figure_C.p","wb"))
#    pickle.dump( diff, open("Figure_D.p","wb"))



#    FEP_scale = pickle.load(open("Figure_A.p","rb"))
#    FES0 = pickle.load(open("Figure_B.p","rb"))
#    exact_FES = pickle.load(open("Figure_C.p","rb"))
#    diff = pickle.load(open("Figure_D.p","rb"))

#    FEP_scale = pickle.load(open("Figure_C.p","rb"))
#    FES0 = pickle.load(open("Figure_B.p","rb"))
#    exact_FES = pickle.load(open("Figure_A.p","rb"))
#    diff = pickle.load(open("Figure_D.p","rb"))

    fig, ax = plt.subplots(2,2,sharex=True,sharey=True)
    im = ax[0,0].imshow(FEP_scale,origin='lower',extent=[0,1,0,1],vmin=0.0,vmax=40.0,cmap='viridis',aspect='auto')
    cbar = fig.colorbar(im,ax=ax[0,0],fraction=0.046,pad=0.04)
    cbar.ax.tick_params(labelsize=14)

    im = ax[0,1].imshow(FES0,origin='lower',extent=[0,1,0,1],vmin=0.0,vmax=40.0,aspect='auto')               
    cbar = fig.colorbar(im,ax=ax[0,1],fraction=0.046,pad=0.04)              
    cbar.ax.tick_params(labelsize=14) 

    ax[0,0].text(-0.3,1.05,'A',fontsize=20)
    ax[0,1].text(-0.3,1.05,'B',fontsize=20)
    ax[1,0].text(-0.3,1.05,'C',fontsize=20)
    ax[1,1].text(-0.3,1.05,'D',fontsize=20)

    ax[1,0].set_xlabel('x',fontsize=20)
    ax[1,0].set_ylabel('y',fontsize=20)
    ax[1,1].set_xlabel('x',fontsize=20)
    ax[0,0].set_ylabel('y',fontsize=20)

    ax[0,0].tick_params(axis='both',which='major', labelsize=14)
    ax[0,1].tick_params(axis='both',which='major', labelsize=14)
    ax[1,0].tick_params(axis='both',which='major', labelsize=14)
    ax[1,1].tick_params(axis='both',which='major', labelsize=14)

    im = ax[1,0].imshow(exact_FES,origin='lower',extent=[0,1,0,1],vmin=0.0,vmax=40.0,aspect='auto')
    cbar = fig.colorbar(im,ax=ax[1,0],fraction=0.046,pad=0.04)              
    cbar.ax.tick_params(labelsize=14)     
    
    elev_min = -5.0
    elev_max = 20.0
    mid_val = 0.0

    im = ax[1,1].imshow(diff,origin='lower',extent=[0,1,0,1],cmap='RdBu',clim=(elev_min,elev_max),norm=MidpointNormalize(midpoint=mid_val,vmin=elev_min,vmax=elev_max),aspect='auto')
    cbar = fig.colorbar(im,ax=ax[1,1],fraction=0.046,pad=0.04)
    cbar.ax.tick_params(labelsize=14)
    fig.tight_layout()

    plt.show()


    """
    layer0 = np.array(mysim.layers[0].xys_hist)
    layer1 = np.array(mysim.layers[1].xys_hist)
    layer2 = np.array(mysim.layers[2].xys_hist)
    print layer0
    print layer1
    print layer2
    print len(layer0)
    print len(layer1)
    print len(layer2)
    layer1 = layer1.reshape((step_arr[0],step_arr[1]+1,2))
    layer2 = layer2.reshape((step_arr[0],step_arr[1],step_arr[2]+1,2))

    nx = 500
    ny = 500
    xvec = np.linspace(-0.00,1.00,nx)
    yvec = np.linspace(-0.00,1.00,ny)
    gx,gy = np.meshgrid(xvec,yvec)
    Ug = np.zeros(gx.shape)
    coeffs = pes.load_coeffs()

    for i in range(nx):
        for j in range(ny):
            Ug[i,j] = pes.evaluate(0.0,[gx[i,j],gy[i,j]],*coeffs)
    fS = 16

    print('plotting trajectory...')
    ind = 0
    for i in range(step_arr[0]):
        for k in range(step_arr[1]):
            plt.plot(layer0[:i+1,0],layer0[:i+1,1],'--o',linewidth=3.0,color='r',label='1.0',alpha=1.0)
            plt.plot(layer1[i,:k+1,0],layer1[i,:k+1,1],'--o',linewidth=2.0,color='b',label='0.5',alpha=1.0)
            plt.plot(0,0,color='k',label='0.2')
            plt.contourf(gx,gy,Ug,20, cmap=cm.coolwarm,alpha=0.8)
#            plt.show()
#            sys.exit()
            for j in range(step_arr[2]):
                basex = layer2[i,k,j][0]
                basey = layer2[i,k,j][1]
                ptx = layer2[i,k,j+1][0]
                pty = layer2[i,k,j+1][1]
                dx = ptx-basex
                dy = pty-basey
                plt.arrow(basex,basey,dx,dy,head_width=0.01,head_length=0.01,ec='k',alpha=1.0)
            plt.xlim(-0.00,1.00)
            plt.ylim(-0.00,1.00)
            plt.xlabel('x',fontsize=20)
            plt.ylabel('y',fontsize=20)
            plt.tick_params(axis='both', which='major', labelsize=14)            
#                plt.title("CAPS trajectory")
            plt.legend()
            plt.savefig("image_{0:03d}.png".format(ind))
            plt.close()
            print(ind)
            ind += 1
#            plt.show()
#            sys.exit()


    sys.exit()
    """
    print("Simulation Finished")



#    plt.plot(pot_call_list,E_list)
#    plt.plot(pot_call_list,RMSE_list)
#    plt.show()
    #Plotting surfaces


#    i,j = np.unravel_index(mysim.prob_hist.argmax(), mysim.prob_hist.shape)
#    print(i,j)
#    i,j = np.unravel_index(mysim.exact_prob_hist.argmax(), mysim.exact_prob_hist.shape)
#    print(i,j)


#    fig, ax = plt.subplots(4,mysim.num_layers,sharex=True,sharey=True)
#    fig, ax = plt.subplots(2,2,sharex=True,sharey=True)
#    im = ax[0,0].imshow(mysim.FEP_FES_surf,origin='lower')
#    ax[0,0].set_title('FEP Approximate Surface',fontsize=10)
#    cbar = fig.colorbar(im,ax=ax[0,0],fraction=0.046,pad=0.04)
#    cbar.ax.tick_params(labelsize=6)

#    im = ax[0,1].imshow(mysim.prob_hist,origin='lower')
#    ax[0,1].set_title('FEP Probability Surface',fontsize=10)
#    cbar = fig.colorbar(im,ax=ax[0,1],fraction=0.046,pad=0.04)
#    cbar.ax.tick_params(labelsize=6)

#    im = ax[0,2].imshow(mysim.exact_prob_hist,origin='lower')
#    ax[0,2].set_title('Exact Probability Surface',fontsize=10)
#    cbar = fig.colorbar(im,ax=ax[0,2],fraction=0.046,pad=0.04)
#    cbar.ax.tick_params(labelsize=6)

#    im = ax[0,3].imshow(np.abs(mysim.exact_prob_hist-mysim.prob_hist),origin='lower')
#    ax[0,3].set_title('Absolute Difference',fontsize=10)
#    cbar = fig.colorbar(im,ax=ax[0,3],fraction=0.046,pad=0.04)
#    cbar.ax.tick_params(labelsize=6)


#    for i in range(mysim.num_layers):
#        im = ax[1,i].imshow(mysim.FES_surfaces[i],origin='lower')
#        ax[1,i].set_title('Layer '+str(i)+' FES',fontsize=10)
#        cbar = fig.colorbar(im,ax=ax[1,i],fraction=0.046,pad=0.04)
#        cbar.ax.tick_params(labelsize=6)
#    for i in range(mysim.num_layers):
#        im = ax[2,i].imshow(mysim.FEP_hist[i],origin='lower')
#        ax[2,i].set_title('Layer '+str(i)+'-'+str(i+1)+' FEP',fontsize=10)
#        cbar = fig.colorbar(im,ax=ax[2,i],fraction=0.046,pad=0.04)
#        cbar.ax.tick_params(labelsize=6)
#    for i in range(4,mysim.num_layers):
#        ax[0,i].axis('off')
#    fig.tight_layout()
#    plt.show()

main()





"""                                                                                                 
   #THIS SECTION IS USED TO MAKE THE MOVIE
    nx = 500                                                                                               
    ny = 500                                                                                               
    xvec = np.linspace(-0.05,1.05,nx)                                                                      
    yvec = np.linspace(-0.05,1.05,ny)                                                                      
    gx,gy = np.meshgrid(xvec,yvec)                                                                         
    Ug = np.zeros(gx.shape)                                                                                
    coeffs = pes.load_coeffs()                                                                             
                                                                                                       
    for i in range(nx):                                                                                    
        for j in range(ny):                                                                                
            Ug[i,j] = pes.evaluate(0.0,[gx[i,j],gy[i,j]],*coeffs)                                          
    fS = 16                                                                                                
                                                                                                       
    print 'plotting trajectory...'                                                                         
    ind = 0                                                                                                
    for i in range(step_arr[0]):                                                                           
        for k in range(step_arr[1]):                                                                       
            plt.plot(layer0[:i+1,0],layer0[:i+1,1],'--o',linewidth=4.0,color='r',label=str(pot_arr[0]),alpha=1.0)                                                                                                
            plt.plot(layer1[i,:k+1,0],layer1[i,:k+1,1],'--o',linewidth=2.0,color='b',label=str(pot_arr[1]),alpha=1.0)                                                                                            
            if mysim.num_layers == 3:                                                                      
                plt.plot(0,0,color='k',label=str(pot_arr[2]))                                              
            plt.contourf(gx,gy,Ug,20, cmap=cm.coolwarm,alpha=0.8)                                          
            if mysim.num_layers > 2:                                                                       
                for j in range(step_arr[2]):                                                               
                    basex = layer2[i,k,j][0]                                                               
                    basey = layer2[i,k,j][1]                                                               
                    ptx = layer2[i,k,j+1][0]                                                               
                    pty = layer2[i,k,j+1][1]                                                               
                    dx = ptx-basex                                                                         
                    dy = pty-basey                                                                         
                    plt.arrow(basex,basey,dx,dy,head_width=0.01,head_length=0.01,ec='k',alpha=1.0)         
                plt.xlim(-0.05,1.05)                                                                       
                plt.ylim(-0.05,1.05)                                                                       
                plt.title("CAPS trajectory")                                                               
                plt.legend()                                                                               
                plt.savefig("image_{0:03d}.png".format(ind))                                               
                plt.close()                                                                                
                print ind                                                                                  
                ind += 1                                                                                   
#        plt.show()                                                                                    
"""                                                                                                       
                                                                                                                                                                                                       

