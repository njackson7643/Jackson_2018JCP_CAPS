import os
import sys
import numpy as np
from sys import argv
import matplotlib.pyplot as plt

def read_file(filename):
    count = -1
    x_list = []
    E_list = []
    with open(filename,'r') as f:
        for i,line in enumerate(f):
            templine = line.split()
            if len(templine) >= 2:
                if templine[0] == 'mean_energy:' or templine[1] == 'energy':
                    count += 1
                    x_list.append(count)
                    E_list.append(float(templine[-1]))
    return np.array(x_list),-1.0*(np.array(E_list)+1.115)/(-1.115)

script, file1 = argv

x,E = read_file(file1)

#print(x)
#print(E)

with open('E_v_sweep.txt','w') as f:
    for i in range(len(x)):
        f.write("{} \t {} \n".format(x[i],E[i]))

plt.plot(x,E)
plt.axhline(0.0,linewidth=2.0,color='red')
plt.ylim(-0.02,0.02)
plt.xlim(0,50000)
plt.show()
