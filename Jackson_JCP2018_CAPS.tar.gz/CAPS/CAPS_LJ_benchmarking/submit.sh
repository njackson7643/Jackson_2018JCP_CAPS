#!/bin/sh
#SBATCH --job-name=test
#SBATCH --output=test2.out
#SBATCH --time=72:00:00
#SBATCH --partition=testpart
#SBATCH --nodes=1

python CAPS_2D_LJ_errorgauge.py > test.out
