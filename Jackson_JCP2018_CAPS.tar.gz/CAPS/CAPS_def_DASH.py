import numpy as np
from random import random
import matplotlib.pyplot as plt
import math
import sys




#Class for a given layer of the CAPS MC - Has own unique level number, number of MC steps, and potential value

class Layer:
    def __init__(self, num, steps, state):
        self.layer_num = num                          #Layer number
        self.nsteps = steps                           #Number of MC steps within that layer
       # self.pot = pot                                #Coarseness of potential
       # self.xs = 2.0                                 #Variable to hold saved coordinate
       # self.xt = 2.0                                 #Variable to hold trial coordinate
        self.state = state
        self.beta = 1.0/state.helpers['temp']         #Beta temperature param for MC accept
        self.Es = potential(pot,self.xs)          #Variable to hold potential for xs
        self.Et = 0.0                                 #Variable to hold potential for xt

    def run(self):
        self.state.helpers['integrator'].run(self.nsteps)
    def setPositions(self, positions):
        savedPositions = [a.pos.copy() for a in state.atoms]
        for a, p in zip(state.atoms, positions):
            a.pos = p
        return savedPositions
    def potential(self, positions=None):
        savedPositions=None
        if positions:
            savedPositions = self.setPositions(positions)
        engData = self.state.dataManager.recordEnergy(interval=1)
        savedDt = self.state.dt
        self.state.dt = 0
        self.run(1)
        energy = engData.vals[0]
        self.state.dt = savedDt
        if savedPositions:
            self.setPositions(savedPositions)
        self.state.dataManager.stopRecord(engData)
        return energy



#Class that holds all MC layers of the simulation
class Sim:
    def __init__(self, steps_arr, states):
        if len(steps_arr) != len(states):
            print "Layer input is incorrect, exiting..."
            sys.exit()
        else:
            self.steps_arr = steps_arr
            self.pot_arr = pot_arr
            self.num_layers = len(steps_arr)
            self.first_layer = 0
            self.last_layer = self.num_layers-1
            self.layers = []
            for i in range(self.num_layers):
                self.layers.append(Layer(i, steps_arr[i], states[i]))

    #Method that performs the deltaE1-deltaE0 check between MC layers of simulation

    def metropolis(self, layerHi, layerLo):
        eng_final_hi = layerHi.potential()
#this is fine because layerLo has the initial config
        eng_initial_lo = layerLo.potential()

        finalPoses = [a.pos.copy() for a in layerHi.state.atoms]
        initPoses = [a.pos.copy() for a in layerLo.state.atoms]

        eng_final_lo = layerLo.potential(finalPoses)
        eng_initial_hi = layerHi.potential(initPoeses)
        assert(layerHi.beta==layerLo.beta)

#1 -> hi-res
#0 -> lo-res
        deltaE0 = eng_final_lo - eng_initial_lo
        deltaE1 = eng_final_hi - eng_initial_hi

        rand = random()

        prob = math.exp(-beta*(deltaE0-deltaE1))

        if rand_num <= prob:
            return True
        else:
            return False
    def assignState(self, layerFrom, layerTo):
        posFrom = [a.pos.copy() for a in layerFrom.state.atoms]
        velFrom = [a.vel.copy() for a in layerFrom.state.atoms]

        for pos, vel, atom in zip(posFrom, velFrom, layerTo.atoms):
            atom.pos = pos
            atom.vel = vel

    #Recursive method that runs an arbitrary number of nested loops.  This is where the meat is.
    def run_CAPS(self,level):
        #If there is only one layer, run a normal MD
        if level == 0 and self.last_layer == 0:
#just run for nsteps
            self.layers[level].run()
        #If there are many layers and its the first layer,launch MD and descend to next layer
        elif level == 0 and level != self.last_layer:
            for i in range(self.layers[level].nsteps):
                print 'iteration '+str(i)+' in layer '+str(level)
                self.run_CAPS(level+1)
        #If there are many layers and its not the first or last layer
        elif level != 0 and level != self.last_layer:
            for k in range(self.layers[level].nsteps):
#okay so climbing even further up
                self.run_CAPS(level+1)
            self.layers[level-1] += 1
            if self.metropolis(self.layers[level], self.layers[level-1]):
                self.layers[level-1].acc_count += 1
                assignState(self.layers[level], self.layers[level-1])
            else:
                assignState(self.layers[level-1], self.layers[level]


        #If there are many layers and it is the last layer
        elif level == self.last_layer:
#so last_layer is the only one where any running happens?
            self.layers[level].run()

            self.layers[level-1].att_count += 1
            if self.metropolis(self.layers[level], self.layers[level-1]):
                self.layers[level-1].acc_count += 1
                assignState(self.layers[level], self.layers[level-1])
            else:
                assignState(self.layers[level-1], self.layers[level])

    def print_acc_ratio(self):
        for layer in self.layers:
            print "Acceptance ratio in layer "+str(layer.layer_num)+": "+str((layer.acc_count)/float(layer.att_count))


