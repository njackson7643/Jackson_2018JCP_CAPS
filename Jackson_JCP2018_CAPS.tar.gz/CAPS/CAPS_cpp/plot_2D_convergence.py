import os
import sys
import matplotlib.pyplot as plt

x = [1,2,3,4,5,6,7,8,9,10]
y = [0.0181,0.0113,0.0068,0.0045,0.0023,0.0011,0.0,0.0,0.0,0.0]


plt.plot(x,y,'-o',linewidth=2,color='black')
plt.xlabel(r'$N_{middle}$',fontsize=16)
plt.ylabel(r'$|\frac{E_{ref}-E_{sim}}{E_{sim}}|$',fontsize=16)
plt.tight_layout()
plt.show()
