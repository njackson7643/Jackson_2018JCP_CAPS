import os
import sys
import numpy as np
import matplotlib.pyplot as plt

def read_file(filename):
    y = []
    with open(filename,'r') as f:
        for i,line in enumerate(f):
            templine = line.split()
            if len(templine) == 4 and templine[0] != 'total' and templine[0] != 'It':
                y.append(float(templine[1]))
    return np.array(y)

layer_1 = read_file('output_1layer_Edist.txt')
layer_2 = read_file('output_2layer_Edist.txt')
layer_3 = read_file('output_3layer_new.txt')
layer_4 = read_file('output_4layer_new.txt')

num_b = 25

r1,e1 = np.histogram(layer_1, bins=num_b, range=(-1.3,-0.9), normed=True)
r2,e2 = np.histogram(layer_2, bins=num_b, range=(-1.3,-0.9), normed=True)
r3,e3 = np.histogram(layer_3, bins=num_b, range=(-1.3,-0.9), normed=True)
r4,e4 = np.histogram(layer_4, bins=num_b, range=(-1.3,-0.9), normed=True)

#plt.plot(e1[:-1],np.log(np.divide(r1,r1)),label='1 layer')
#plt.plot(e1[:-1],np.log(np.divide(r2,r1)),label='2 layer')
#plt.plot(e1[:-1],np.log(np.divide(r3,r1)),label='3 layer')
#plt.plot(e1[:-1],np.log(np.divide(r4,r1)),label='4 layer')
#plt.ylabel(r'$ln(P_n(E/N)/P_1(E/N))$')
#plt.xlabel('E/N')
#plt.legend()
#plt.show()
#sys.exit()

fig, ax = plt.subplots(2,2)
binwidth = e1[1]-e1[0]
ax[1,1].plot(e1[:-1],np.log(np.divide(r1,r1)),label='1 layer')
ax[1,1].plot(e2[:-1],np.log(np.divide(r2,r1)),label='2 layer')
ax[1,1].plot(e3[:-1],np.log(np.divide(r3,r1)),label='3 layer')
ax[1,1].plot(e4[:-1],np.log(np.divide(r4,r1)),label='4 layer')
ax[0,0].plot(e1[:-1],r1,'-o',label='1 layer',color='black')
ax[0,0].plot(e1[:-1],r2,'-x',label='2 layers')
ax[0,1].plot(e1[:-1],r1,'-o',label='1 layer',color='black')
ax[0,1].plot(e1[:-1],r3,'-x',label='3 layers')
ax[1,0].plot(e1[:-1],r1,'-o',label='1 layer',color='black')
ax[1,0].plot(e1[:-1],r4,'-x',label='4 layers')
ax[0,0].legend()
ax[0,1].legend()
ax[1,0].legend()
ax[1,1].legend()

ax[1,0].set_xlabel('E/N',fontsize=16)
ax[1,1].set_xlabel('E/N',fontsize=16)
ax[1,1].set_ylabel(r'$ln(P_n(E/N)/P_1(E/N))$',fontsize=16)
ax[1,1].set_ylim(-1.0,1.0)
ax[0,0].set_ylabel('P(E/N)',fontsize=16)
ax[1,0].set_ylabel('P(E/N)',fontsize=16)
plt.tight_layout()
plt.show()

