#include <vector>
#include <iostream>
#include "stdio.h"
#include "math.h"
#include "tgmath.h"
#include "random_mars.h"
#include <time.h>

using namespace std;

class sim_param
{
 public:
  double boxl,area,max_disp,beta,eps,sig,sig6,sig12;
  int num_layers,Ntot,last_layer;
  vector<int> steps_arr;
  vector<double> pot_arr;
  sim_param();
};

sim_param::sim_param () {
  boxl = 0.0;
  area = 0.0;
  max_disp = 0.0;
  beta = 0.0;
  eps = 0.0;
  sig = 0.0;
  num_layers = 0;
  last_layer = 0;
  sig6 = 0.0;
  sig12 = 0.0;
  Ntot = 0;
}

class layer
{
 public:
  long int pot_calls;
  int layer_num,nsteps,numevals_LJ;
  double rcut,E_sum,P_sum,count_sum,att_count,acc_count;
  tuple<double,double> EPtemp;
  double Es,Et;
  double Ps,Pt;
  sim_param global_p;
  vector< vector<double> > xy;
  layer();
  layer(int,int,double,vector<vector<double>>,sim_param);
  tuple<double,double> LJ_pot(double,double,double,double);
  tuple<double,double> wrap_xyz(double,double);
  tuple<double,double> NIC(double,double);
  tuple<double,double> full_quadratic_E_P(double);
  tuple<double,double> single_quadratic_E_P(double,int);
  void metropolis();
  void equilibrate(int);
  RanMars *layer_random;
};

layer::layer(){
  pot_calls=0,layer_num=0,numevals_LJ=0;
  rcut=0.0,E_sum=0.0,P_sum=0.0,count_sum=0.0,att_count=0.0,acc_count=0.0;
  Es=0.0,Et=0.0;
  Ps=0.0,Pt=0.0;
}

layer::layer(int t_num, int t_steps, double t_rcut, vector<vector<double>> t_xy, sim_param t_params){
  pot_calls=0,numevals_LJ=0;
  E_sum=0.0,P_sum=0.0,count_sum=0,att_count=0.0,acc_count=0.0;
  Es=0.0,Et=0.0;
  Ps=0.0,Pt=0.0;
  nsteps = t_steps;
  layer_num = t_num;
  rcut = t_rcut;
  xy = t_xy;
  global_p = t_params;
  layer_random = new RanMars(t_num+time(NULL)%1000);
  EPtemp = full_quadratic_E_P(rcut);
  Es = get<0>(EPtemp);
  Ps = get<1>(EPtemp);
  Et = Es;
  Pt = Ps;
}

tuple<double,double> layer::LJ_pot(double t_eps, double t_sig6, double t_sig12, double t_r2){
  double r6 = t_r2*t_r2*t_r2;
  double sig6r6 = t_sig6/r6;
  double sig12r12 = sig6r6*sig6r6;
  double E = 4.*t_eps*(sig12r12-sig6r6);
  double P = -4.*t_eps*(12.0*sig12r12-6.0*sig6r6);
  pot_calls += 1;
  return make_tuple(E,P);
}

tuple<double,double> layer::wrap_xyz(double t_x,double t_y){
  double t_boxl = global_p.boxl;
  double xnew=t_x;
  double ynew=t_y;
  if (xnew > t_boxl){xnew -= t_boxl;}
  else if (xnew < 0.0){xnew += t_boxl;}
  if (ynew > t_boxl){ynew -= t_boxl;}
  else if (ynew < 0.0){ynew += t_boxl;}
  return make_tuple(xnew,ynew);
}

tuple<double,double> layer::NIC(double t_x,double t_y){
  double t_boxl = global_p.boxl;
  double dx_new=t_x;
  double dy_new=t_y;
  if (dx_new > t_boxl/2.){dx_new -= t_boxl;}
  else if (dx_new <= -t_boxl/2.){dx_new += t_boxl;}
  if (dy_new > t_boxl/2.){dy_new -= t_boxl;}
  else if (dy_new <= -t_boxl/2.){dy_new += t_boxl;}
  return make_tuple(dx_new,dy_new);
}

tuple<double,double> layer::single_quadratic_E_P(double t_rcut,int t_num){
  double rcut2 = t_rcut*t_rcut;
  double Etot=0.0,Ptot=0.0;
  double xi=0.0,yi=0.0,xj=0.0,yj=0.0;
  double dx=0.0,dy=0.0,dr2=0.0;
  tuple<double,double> dxy;
  tuple<double,double> EPtemp;
  xi = xy[t_num][0];
  yi = xy[t_num][1];
  for (int i=0;i<global_p.Ntot;i++){
    if (i != t_num){
      xj = xy[i][0];
      yj = xy[i][1];
      dxy = NIC(xj-xi,yj-yi);
      dx = get<0>(dxy);
      dy = get<1>(dxy);
      dr2 = dx*dx+dy*dy;
      EPtemp = make_tuple(0.0,0.0);
      if (dr2 <= rcut2){
	numevals_LJ += 1;
	EPtemp = LJ_pot(global_p.eps,global_p.sig6,global_p.sig12,dr2);
	Etot += get<0>(EPtemp);
	Ptot += get<1>(EPtemp);
      }
    }
  }
  return make_tuple(Etot,Ptot);
}

tuple<double,double> layer::full_quadratic_E_P(double t_rcut){
  //  cout << "running full energy..." << endl;
  double rcut2 = t_rcut*t_rcut;
  double Etot=0.0,Ptot=0.0;
  double xi=0.0,yi=0.0,xj=0.0,yj=0.0;
  double dx=0.0,dy=0.0,dr2=0.0;
  tuple<double,double> dxy;
  tuple<double,double> EPtemp;
  for (int i=0;i<global_p.Ntot;i++){
    xi = xy[i][0];
    yi = xy[i][1];
    for(int j=i+1;j<global_p.Ntot;j++){
      xj = xy[j][0];
      yj = xy[j][1];
      dxy = NIC(xj-xi,yj-yi);
      dx = get<0>(dxy);
      dy = get<1>(dxy);
      dr2 = dx*dx+dy*dy;
      EPtemp = make_tuple(0.0,0.0);
      if (dr2 <= rcut2){
	numevals_LJ += 1;
	EPtemp = LJ_pot(global_p.eps,global_p.sig6,global_p.sig12,dr2);
	Etot += get<0>(EPtemp);
	Ptot += get<1>(EPtemp);
      }
    }
  }
  return make_tuple(Etot,Ptot);
}   

void layer::equilibrate(int warm_steps){
  for(int i=0;i<warm_steps;i++){
    metropolis();
  }
  att_count = 0;
  acc_count = 0;
  pot_calls = 0;
}

void layer::metropolis(){
  double dE=0.0,dP=0.0;
  tuple<double,double> EP_before;
  tuple<double,double> EP_after;
  tuple<double,double> xytemp;
  double dx=0.0,dy=0.0,newx=0.0,newy=0.0,oldx=0.0,oldy=0.0;
  double rand_test=0.0,boltz_fact=0.0;
  int parti = 0;
  Et = Es;
  Pt = Ps;
  att_count += 1.0;
  parti = int(layer_random->uniform()*global_p.Ntot);
  EP_before = single_quadratic_E_P(rcut,parti);
  //  EP_before = full_quadratic_E_P(rcut);
  dx = (layer_random->uniform()-0.5)*global_p.max_disp;
  dy = (layer_random->uniform()-0.5)*global_p.max_disp;
  oldx = xy[parti][0];
  oldy = xy[parti][1];
  newx = oldx + dx;
  newy = oldy + dy;
  xytemp = wrap_xyz(newx,newy);
  newx = get<0>(xytemp);
  newy = get<1>(xytemp);
  xy[parti][0] = newx;
  xy[parti][1] = newy;
  //  EP_after = full_quadratic_E_P(rcut);
  EP_after = single_quadratic_E_P(rcut,parti);
  dE = get<0>(EP_after)-get<0>(EP_before);
  dP = get<1>(EP_after)-get<1>(EP_before);
  Et += dE;
  Pt += dP;
  if (Et < Es){
    Es = Et;
    Ps = Pt;
    acc_count += 1.0;
    xy[parti][0] = newx;
    xy[parti][1] = newy;
  }
  else if (Et >= Es){
    rand_test = layer_random->uniform();
    boltz_fact = exp(-1.0*global_p.beta*dE);
    if (rand_test < boltz_fact){
      Es = Et;
      Ps = Pt;
      acc_count += 1.0;
      xy[parti][0] = newx;
      xy[parti][1] = newy;
    }
    else{
      Et = Es;
      Pt = Ps;
      xy[parti][0] = oldx;
      xy[parti][1] = oldy;
    }
  }
}

class sim
{
 public:
  sim_param params;
  RanMars *sim_random;
  FILE *fptr;
  FILE *gptr;
  vector<layer> sim_layers;
  vector<vector<double>> xy;
  sim();
  sim(vector<int>,vector<double>,double,double,double,double,double,int);
  void initialize(void);
  void metropolis_2(int);
  void run_CAPS_LJ(int,FILE*,FILE*);
  void print_acc_ratio();
  void print_pot_calls();
  void record_write(FILE*,FILE*,int,int);
};

sim::sim(vector<int> t_steps, vector<double> t_pot, double t_boxl, double t_beta, double t_max_disp, double t_eps, double t_sig, int t_Ntot){
  params.steps_arr = t_steps;
  params.pot_arr = t_pot;
  params.boxl = t_boxl;
  params.area = params.boxl*params.boxl;
  params.beta = t_beta;
  params.Ntot = t_Ntot;
  params.max_disp = t_max_disp;
  params.num_layers = params.steps_arr.size();
  params.last_layer = params.num_layers-1;
  params.eps = t_eps;
  params.sig = t_sig;
  params.sig6 = pow(params.sig,6.0);
  params.sig12 = params.sig6*params.sig6;
  xy = vector<vector<double>>(params.Ntot, vector<double>(2));
  initialize();
  sim_random = new RanMars(64738+time(NULL)%1000);
  //  fptr = fopen("traj.xyz","w");
  //  gptr = fopen("avgE_list.txt","w");
  for(int i=0;i<params.num_layers;i++){
    sim_layers.push_back(layer(i,params.steps_arr[i],params.pot_arr[i],xy,params));
  }
}

void sim::initialize(void)
{
  //Initialize atoms on a cubic lattice.
  double part_per_side = sqrt(params.Ntot);
  int p_p_side = int(part_per_side);
  double spacing = params.boxl/part_per_side;
  for(int i=0;i<p_p_side;i++){
    for(int j=0;j<p_p_side;j++){
      xy[i*p_p_side+j][0] = spacing/2. + spacing*i;
      xy[i*p_p_side+j][1] = spacing/2. + spacing*j;
      }
  }
}

void sim::metropolis_2(int t_level){
  double E_xf_n1=0.0,E_xi_n1=0.0,E_xf_n0=0.0,E_xi_n0=0.0;
  double P_xf_n1=0.0,P_xi_n1=0.0,P_xf_n0=0.0,P_xi_n0=0.0;
  double deltaE0=0.0,deltaE1=0.0,deltadeltaE=0.0;
  double prob = 0.0,rand_num=0.0;
  double beta = 0.0;
  tuple<double,double> xin1;
  tuple<double,double> xfn0;

  sim_layers[t_level-1].att_count += 1.0;
  beta = params.beta;
  E_xf_n1 = sim_layers[t_level].Es;
  P_xf_n1 = sim_layers[t_level].Ps;
  xin1 = sim_layers[t_level-1].full_quadratic_E_P(sim_layers[t_level].rcut);
  xfn0 = sim_layers[t_level].full_quadratic_E_P(sim_layers[t_level-1].rcut);
  E_xi_n1 = get<0>(xin1);
  P_xi_n1 = get<1>(xin1);
  E_xf_n0 = get<0>(xfn0);
  P_xf_n0 = get<1>(xfn0);
  E_xi_n0 = sim_layers[t_level-1].Es;
  P_xi_n0 = sim_layers[t_level-1].Ps;
  deltaE0 = E_xf_n0-E_xi_n0;
  deltaE1 = E_xf_n1-E_xi_n1;
  deltadeltaE = deltaE0-deltaE1;
  
  if (deltadeltaE < 0.0){
    sim_layers[t_level-1].acc_count += 1;
    sim_layers[t_level-1].Es = E_xf_n0;
    sim_layers[t_level-1].Et = E_xf_n0;
    sim_layers[t_level-1].Ps = P_xf_n0;
    sim_layers[t_level-1].Pt = P_xf_n0;
    sim_layers[t_level-1].xy = sim_layers[t_level].xy;
    sim_layers[t_level].Es = E_xf_n1;
    sim_layers[t_level].Et = E_xf_n1;
    sim_layers[t_level].Ps = P_xf_n1;
    sim_layers[t_level].Pt = P_xf_n1;
  }
  else{
    rand_num = sim_random->uniform();
    if(deltadeltaE > 100000.0){deltadeltaE = 100000.0;}
    prob = exp(-1.0*beta*deltadeltaE);
    if (rand_num < prob){
      sim_layers[t_level-1].acc_count += 1;
      sim_layers[t_level-1].Es = E_xf_n0;
      sim_layers[t_level-1].Et = E_xf_n0;
      sim_layers[t_level-1].Ps = P_xf_n0;
      sim_layers[t_level-1].Pt = P_xf_n0;
      sim_layers[t_level-1].xy = sim_layers[t_level].xy;
      sim_layers[t_level].Es = E_xf_n1;
      sim_layers[t_level].Et = E_xf_n1;
      sim_layers[t_level].Ps = P_xf_n1;
      sim_layers[t_level].Pt = P_xf_n1;
    }
    else{
      sim_layers[t_level-1].Es = E_xi_n0;
      sim_layers[t_level-1].Et = E_xi_n0;
      sim_layers[t_level-1].Ps = P_xi_n0;
      sim_layers[t_level-1].Pt = P_xi_n0;
      sim_layers[t_level].xy = sim_layers[t_level-1].xy;
      sim_layers[t_level].Es = E_xi_n1;
      sim_layers[t_level].Et = E_xi_n1;
      sim_layers[t_level].Ps = P_xi_n1;
      sim_layers[t_level].Pt = P_xi_n1;
    }
  }
}

void sim::record_write(FILE *xyzptr,FILE *Eptr, int j,int t_level){
  fprintf(xyzptr,"%d\t\t cycle %d\n\n",params.Ntot,j);
  for(int r=0;r<params.Ntot;r++){
    fprintf(xyzptr,"H %f %f 0.0\n",sim_layers[t_level].xy[r][0],sim_layers[t_level].xy[r][1]);
  }
  sim_layers[t_level].E_sum += sim_layers[t_level].Es;
  sim_layers[t_level].P_sum += sim_layers[t_level].Ps;
  sim_layers[t_level].count_sum += 1.0;
  fprintf(Eptr,"%d\t%f\n",j,sim_layers[t_level].E_sum/sim_layers[t_level].count_sum/params.Ntot);
}

void sim::run_CAPS_LJ(int t_level,FILE *fptr, FILE *gptr){
  double Vterm = 1./(2.*params.area);
  double mean_E_per_part = 0.0;
  double mean_P_per_part = 0.0;
  if (t_level == 0 && params.last_layer == 0){
    for(int j=0;j<sim_layers[t_level].nsteps;j++){
      sim_layers[t_level].metropolis();
      if (j%1 == 0){
	record_write(fptr,gptr,j,t_level);
	mean_E_per_part = sim_layers[t_level].E_sum/sim_layers[t_level].count_sum/params.Ntot;
	mean_P_per_part = Vterm*(sim_layers[t_level].P_sum/sim_layers[t_level].count_sum); 
	mean_P_per_part += params.Ntot/(params.area*params.beta);
	cout << j << "\t" << sim_layers[t_level].Es/params.Ntot << "\t" << mean_E_per_part << "\t" << mean_P_per_part << endl;
	}
    }
  }
  else if (t_level == 0 && t_level != params.last_layer){
    sim_layers[t_level+1].xy = sim_layers[t_level].xy;
    sim_layers[t_level+1].Es = sim_layers[t_level].Es;
    sim_layers[t_level+1].Ps = sim_layers[t_level].Ps;
    for(int j=0;j<sim_layers[t_level].nsteps;j++){
      if (j%10 == 0){
      	record_write(fptr,gptr,j,t_level);
	mean_E_per_part = sim_layers[t_level].E_sum/sim_layers[t_level].count_sum/params.Ntot;
	mean_P_per_part = Vterm*(sim_layers[t_level].P_sum/sim_layers[t_level].count_sum); 
	mean_P_per_part += params.Ntot/(params.area*params.beta);
	cout << j << "\t" << sim_layers[t_level].Es/params.Ntot  << "\t" << mean_E_per_part << "\t" << mean_P_per_part << endl;
      }
      sim_layers[t_level+1].xy = sim_layers[t_level].xy;
      run_CAPS_LJ(t_level+1,fptr,gptr);
    }
  }
  else if (t_level != 0 && t_level != params.last_layer){
    sim_layers[t_level+1].xy = sim_layers[t_level].xy;
    sim_layers[t_level+1].Es = sim_layers[t_level].Es;
    sim_layers[t_level+1].Ps = sim_layers[t_level].Ps;
    for(int k=0;k<sim_layers[t_level].nsteps;k++){
      sim_layers[t_level+1].xy = sim_layers[t_level].xy;
      run_CAPS_LJ(t_level+1,fptr,gptr);
    }
    metropolis_2(t_level);
  }
  else if (t_level == params.last_layer){
    for(int m=0;m<sim_layers[t_level].nsteps;m++){
      sim_layers[t_level].metropolis();
    }
    metropolis_2(t_level);
  }
  fclose(fptr);
  fclose(gptr);
}

void sim::print_acc_ratio(){
  for(int i=0;i<params.num_layers;i++){
    cout << "Acceptance ratio in layer " << sim_layers[i].layer_num << ": " << sim_layers[i].acc_count/sim_layers[i].att_count << endl;
  }
}

void sim::print_pot_calls(){
  long int tot_calls = 0;
  for(int i=0;i<params.num_layers;i++){
    tot_calls += sim_layers[i].pot_calls;
    cout << "potential calls in layer " << sim_layers[i].layer_num << ": " << sim_layers[i].pot_calls << endl; 
  }
  cout << "total potential calls: " << tot_calls << endl;
}
