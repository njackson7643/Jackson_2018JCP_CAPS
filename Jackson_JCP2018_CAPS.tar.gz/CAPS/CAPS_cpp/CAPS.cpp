#include "CAPS.h"
#include <iostream>

int main()
{
  vector<int> steps_arr = {100000,4,4,16};
  vector<double> pot_arr = {2.5,2.0,1.8,1.6};
  double boxl = 25.2982213;
  double beta = 1.1111111;
  double max_disp = 1.0;
  double eps = 1.0;
  double sig = 1.0;
  int Ntot = 256;  //Must be a number that has an integer square root

  clock_t t;
  t = clock();
  sim mysim(steps_arr,pot_arr,boxl,beta,max_disp,eps,sig,Ntot);  


  mysim.sim_layers[steps_arr.size()-1].equilibrate(10000*256);

  for(int i=0;i<mysim.params.num_layers-1;i++){
    mysim.sim_layers[i].xy = mysim.sim_layers[mysim.params.num_layers-1].xy;
    mysim.sim_layers[i].Es = mysim.sim_layers[mysim.params.num_layers-1].Es;
    mysim.sim_layers[i].Ps = mysim.sim_layers[mysim.params.num_layers-1].Ps;
  }

  FILE *fptr,*gptr;

  fptr = fopen("traj.xyz","w");
  gptr = fopen("avgE_list.txt","w");
  mysim.run_CAPS_LJ(0,fptr,gptr);
  t = clock()-t;
  cout << "It took " << (float)t/CLOCKS_PER_SEC << " seconds "<< endl;
  cout << "Average energy: " << mysim.sim_layers[0].E_sum/mysim.sim_layers[0].count_sum/mysim.params.Ntot << endl;

  mysim.print_acc_ratio();
  mysim.print_pot_calls();

  //  cout << mysim.sim_layers[0].Es << endl;

  //  tuple<double,double> EPtemp;
  //  cout << get<0>(EPtemp) << endl;


}
