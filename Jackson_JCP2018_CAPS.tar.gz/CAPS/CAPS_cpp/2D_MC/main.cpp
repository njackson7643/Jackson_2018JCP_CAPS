
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "tgmath.h"

#include "random_mars.h"

double calc_energy(int,int,double,double*,double*);

int main(int argc, char **argv){
 
  //MCSim *sim;
  RanMars *random;
  random = new RanMars(1);
  
  int natoms = 224;
  double x[natoms];
  double y[natoms];
  double x0,y0;
  int i,j;
  double d,d0,v;
  double alpha;
  double boxl = 1;
  int cycle, ncycles = 100;
  double energy, energy_proposed;
  int accept = 0;
  double K,dA2;
  int Nm[64];
  int m;
  d = 1.0/14.0;
  v = 5;
  d0 = d*(1-pow(2,v-8));
  alpha = d-d0;
  K = 1.5;
  dA2 = (K*K - 1) * d0*d0 / 64;
  for (i=0;i<64;i++){
    Nm[i] = 0;
  }

  ////initialize atoms randomly, just make up for this with equilibration
  //for (i=0;i<natoms;i++){
  //  x[i] = random->uniform();
  //  y[i] = random->uniform();
  //}
  double myx=0,myy=0;
  double dx= 1.0/14., dy = 1.0/16.0;
  double dr2;
  int count=0;
  for (i=0;i<natoms;i++){
    if (myx >= boxl-0.0001) {
      if (count%2 == 0)
        myx = 0.5*dx;
      else 
        myx = 0;
      myy += dy;
      count ++;
    }
    x[i] = myx;
    y[i] = myy;
    myx += dx;
  }
  FILE *fptr;
  fptr = fopen("init.dat","w");
  for (i=0;i<natoms;i++){
    fprintf(fptr,"%f %f\n",x[i],y[i]);
  }
  fclose(fptr);

  fptr = fopen("traj.xyz","w");

    energy = 0;
  for (cycle = 0; cycle < ncycles; cycle++){
    printf("Cycle: %d\n",cycle);
    for(i=0;i<natoms;i++){
        //pick atom
        j = random->uniform() * natoms;
        
        x0 = x[j];
        y0 = y[j];

        dx = alpha*(2.0*random->uniform() - 1.0);
        dy = alpha*(2.0*random->uniform() - 1.0);
        x[j] += dx;
        y[j] += dy;

        //pbc
        if (x[j] >= boxl) x[j] -= boxl;
        if (x[j] < 0)     x[j] += boxl;
        if (y[j] >= boxl) y[j] -= boxl;
        if (y[j] < 0)     y[j] += boxl;

        energy_proposed = calc_energy(natoms,boxl, d0, x,y);
        if (energy_proposed > 0){ //reject move, since hard spheres
           x[j] = x0; 
           y[j] = y0; 
        }
        else{
            energy = energy_proposed;
            accept ++;
        }
    }

    if (cycle > 20){
      //print xyz
      fprintf(fptr,"%d\n\t cycle %d\n",natoms,cycle);
      for (i=0;i<natoms;i++){
        fprintf(fptr,"H %f %f 0.0\n",10*x[i],10*y[i]);
      }

      //calc Nm
      for(i=0;i<natoms-1;i++){
        for(j=i+1;j<natoms;j++){
           dx = x[j] - x[i];
           dy = y[j] - y[i];
           //minimum image convention
           if (dx >= 0.5*boxl) dx -= boxl;
           if (dx <= -0.5*boxl) dx += boxl;
           if (dy >= 0.5*boxl) dy -= boxl;
           if (dy <= -0.5*boxl) dy += boxl;
           dr2 = dx*dx + dy*dy;
           
           m = (dr2 - d0*d0) / dA2;
           if ((m>=0) && (m<64)){
             Nm[m]++;
           }
           else{
                //printf("invalid m %d\n",m);
                //exit(1);
           }
        }
      }
        
    }
  }
  printf("Accepted %d of %d (%f)\n",accept,ncycles*natoms,(double) accept/ncycles/natoms);
  fclose(fptr);

  fptr = fopen("Nm.dat","w");
  for (i=0;i<64;i++){
    fprintf(fptr,"%d %f\n",i,(double)Nm[i]/(ncycles-20));
    //fprintf(fptr,"%d %f\n",i,64*Nm[i]/natoms/(K*K-1)/(ncycles-20));
  }
  fclose(fptr);

}
double calc_energy(int natoms, int boxl, double sig, double *x, double *y){
    int i,j;
    double dx,dy,dr;
    for (i=0;i<natoms-1;i++){
        for (j=i+1;j<natoms;j++){
           dx = x[j] - x[i]; 
           dy = y[j] - y[i]; 
           //minimum image convention
           if (dx >= 0.5*boxl) dx -= boxl;
           if (dx <= -0.5*boxl) dx += boxl;
           if (dy >= 0.5*boxl) dy -= boxl;
           if (dy <= -0.5*boxl) dy += boxl;

           dr = sqrt(dx*dx+dy*dy);
           if (dr < sig) return 1;
        }
    }
    return 0;
}

