from random import random
import numpy as np
import matplotlib.pyplot as plt
import math

def double_well(E,C,x):
    x2=x*x
    x4=x2*x2
    return E*(C*x4-x2)

def trial_move(x,max_disp):
    test_disp = max_disp*(random()-0.5)
    x += test_disp
    return x

def MC_check(x_o,x_t):
    E_t = double_well(E_set,C_set,x_t)
    E_o = double_well(E_set,C_set,x_o)
    deltaE = E_t-E_o
    if deltaE <= 0.0:
        return x_t
    else:
        rand_n = random()
        prob = math.exp(-beta*deltaE)
        if rand_n < prob:
            return x_t
        else:
            return x_o

tot_moves = 10
x_o = 0.0
x_t = 0.0
max_D = 0.5
E_set = 1.0
C_set = 0.1
E_t = 0.0
E_o = 0.0
deltaE = 0.0
beta = 1.0

x_list = []

for i in range(tot_moves):
    x_t = trial_move(x_o,max_D)
    x_o = MC_check(x_o,x_t)
    x_list.append(x_o)  
    
xmin = -5.0
xmax = 5.0
dx = 0.1
ax = np.arange(xmin,xmax,dx)
plot_ax = np.arange(xmin+dx/2.,xmax-dx/2.,dx)
fig,ax1 = plt.subplots()
myhist = np.histogram(x_list,bins=ax)[0]
myhist = myhist/len(x_list)
ax1.bar(plot_ax,myhist,dx,alpha=0.5,color='b')
ax1.set_ylabel('Probability')
ax1.set_xlabel('Position(x)')

ax2 = ax1.twinx()
ax2.plot(ax,double_well(E_set,C_set,ax),'r-',label='PES',linewidth=3.0)
ax2.set_ylim(-E_set/(4.*C_set),2)
ax2.set_ylabel('Potential')
ax2.set_title('MC 1D')
plt.show()
