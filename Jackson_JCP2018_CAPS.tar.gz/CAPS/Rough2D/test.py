import pes2Dgauss as pes
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# setting up a grid to look at the PES
nx = 500
ny = 500
xvec = np.linspace(-0.05,1.05,nx)
yvec = np.linspace(-0.05,1.05,ny)
gx,gy = np.meshgrid(xvec,yvec)
Ug = np.zeros(gx.shape)

# first load the coefficients for PES as follows
coeffs = pes.load_coeffs()

# testing the evaluation
for i in range(nx):
    for j in range(ny):
        Ug[i,j] = pes.evaluate(0.0,[gx[i,j],gy[i,j]],*coeffs)

# Plotting the 3D
#fS = 16
#fig = plt.figure(figsize=(6.5,5.0),dpi=800)
#plt.rcParams['mathtext.fontset'] = 'stixsans'
#ax = fig.add_subplot(111,projection='3d')
#surf = ax.plot_surface(gx,gy,Ug,cmap=cm.coolwarm,linewidth=0,rstride=5,cstride=5,antialiased=True,shade=True)
#cbar = fig.colorbar(surf,shrink=0.5,aspect=10,fraction=0.1,format="%4.1f")
#plt.xlabel(r'x',fontsize=fS,fontweight='bold')
#plt.ylabel(r'y',fontsize=fS,fontweight='bold')
#ax.set_zlabel(r'U(x,y)',fontsize=fS,fontweight='bold')
#plt.xlim(0,1.0)
#plt.ylim(0,1.0)
#ax.set_zlim(-20,20)
#plt.savefig("pes.png")

# Plotting the Projection
fS = 16
fig = plt.figure(figsize=(6.5,5.0),dpi=800)
plt.rcParams['mathtext.fontset'] = 'stixsans'
ax = fig.add_subplot(111)
surf = plt.contour(gx,gy,Ug,20, colors='k',linewidths=2,linestyles='solid')
surf = plt.contourf(gx,gy,Ug,20, cmap=cm.coolwarm)
#surf = ax.plot_surface(gx,gy,Ug,cmap=cm.coolwarm,linewidth=0,rstride=5,cstride=5,antialiased=True,shade=True)
cbar = fig.colorbar(surf,shrink=0.5,aspect=10,fraction=0.1,format="%4.1f")
plt.xlabel(r'x',fontsize=fS,fontweight='bold')
plt.ylabel(r'y',fontsize=fS,fontweight='bold')
plt.xlim(-0.05,1.05)
plt.ylim(-0.05,1.05)
plt.savefig("pes.contour.png")
