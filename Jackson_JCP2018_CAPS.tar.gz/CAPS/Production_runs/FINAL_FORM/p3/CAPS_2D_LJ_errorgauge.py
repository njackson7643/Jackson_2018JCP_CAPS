#from CAPS_2D_LJ_def_idiotic import *
from CAPS_2D_LJ_def_simple import *

step_arr = [100000*256]
pot_arr = [['exact',2.5]]

#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
#Kob-Anderson parameters: epsAA=1.0,sigAA=1.0,epsAB=1.5,sigAB=0.8,epsBB=0.5,sigBB=0.88
mysim = Sim(step_arr,pot_arr,29.2119,256,0,1.0,1.0,0.5,0.88,'final.xyz')
#25.2982213 is box length to use for high dens (0.4) results
#29.2119 is box length to use for results data
#22.627417 for 0.5 density
#ADD FINAL.XYZ TO THE END OF THIS TO LOAD IN AN EQUILIBRATED FILE
#append 'final_save.xyz' at the end of the Sim call to load in pre-equilibrated geometry
#Defaults to arithmetic/geometric mixing, so must set cross-terms directly
mysim.params.beta = 1.11111

mysim.run_CAPS_LJ(0)



