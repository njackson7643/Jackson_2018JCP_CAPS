import numpy as np
from random import random
from random import randint
import matplotlib.pyplot as plt
import math
import sys

#class for carrying the global simulation parameters that don't vary from layer to layer
class Sim_param:
    def _init__(self):
        self.boxl = 0
        self.NA = 0
        self.NB = 0
        self.Ntot = 0
        self.max_disp = 0
        self.beta = 0
        self.epsA = 0                               #LJ epsilon parameter for type A
        self.sigA = 0                               #LJ sigma parameter for type A
        self.epsB = 0                               #LJ epsilon parameter for type B
        self.sigB = 0                               #LJ sigma parameter for type B
        self.epsAB = 0              #LJ epsilon for AB cross-term
        self.sigAB = 0                    #LJ sigma for AB cross-term
        self.sigA6 = 0                     #Pre-computed sig^6,sig^12
        self.sigB6 = 0
        self.sigAB6 = 0
        self.sigA12 = 0
        self.sigB12 = 0
        self.sigAB12 = 0
        self.rcut_base = 0               #the base interaction cutoff for the system
        self.part_dict = {}              #Dictionary to hold types of all particles
        self.AA_dict = {}
        self.AB_dict = {}
        self.BB_dict = {}

#class for carrying the specific xyz, parameters for a specific layer
class Layer:
    def __init__(self,num,steps,rt,rcut,xyz,params):
        self.layer_num = num
        self.nsteps = steps
        self.numevals_LJ = 0
        self.numevals_soft = 0
        self.rt = rt
        self.rcut = rcut
#        self.beta = 1.0
        self.xyz_hist = []
        self.sep_hist = []
        self.E_list = []
        self.att_count = 0
        self.acc_count = 0
        self.rt2 = self.rt*self.rt
        self.rcut2 = self.rcut*self.rcut
        self.rcut6 = self.rcut2*self.rcut2*self.rcut2
        self.rcut12 = self.rcut6*self.rcut6
        self.global_p = Sim_param()
        self.global_p = params
        self.xyz = np.copy(xyz)
        self.AA_A = self.global_p.AA_dict[self.rt][0]
        self.AA_B = self.global_p.AA_dict[self.rt][1]
        self.AB_A = self.global_p.AB_dict[self.rt][0]
        self.AB_B = self.global_p.AB_dict[self.rt][1]
        self.BB_A = self.global_p.BB_dict[self.rt][0]
        self.BB_B = self.global_p.BB_dict[self.rt][1]
        self.currE = self.full_quadratic_E(self.rt,self.rcut)

    def separation(self,part0,part1):
        x0,y0,z0 = self.xyz[part0]
        x1,y1,z1 = self.xyz[part1]
        dx = x1-x0
        dy = y1-y0
        dz = z1-z0
        return math.sqrt(dx*dx+dy*dy+dz*dz)

    #LJ cut shifted potential
    def LJ_pot(self,eps,sig6,sig12,r2):
        r6 = r2*r2*r2
        r12 = r6*r6
        return 4.*eps*(sig12/r12 - sig6/r6 - sig12/self.rcut12 + sig6/self.rcut6)

    def wrap_xyz(self,parti,xy,yt,zt):
        boxl = self.global_p.boxl
        if self.xyz[parti,0] > boxl:
            self.xyz[parti,0] -= boxl
        elif self.xyz[parti,0] < 0:
            self.xyz[parti,0] += boxl
        if self.xyz[parti,1] > boxl:
            self.xyz[parti,1] -= boxl
        elif self.xyz[parti,1] < 0:
            self.xyz[parti,1] += boxl
        if self.xyz[parti,2] > boxl:
            self.xyz[parti,2] -= boxl
        elif self.xyz[parti,2] < 0:
            self.xyz[parti,2] += boxl

    def NIC(self,dx,dy,dz):
        boxl = self.global_p.boxl
        if abs(dx) > boxl/2.:
            dx = abs(boxl-abs(dx))
        if abs(dy) > boxl/2.:
            dy = abs(boxl-abs(dy))
        if abs(dz) > boxl/2.:
            dz = abs(boxl-abs(dz))
        return dx,dy,dz

    def full_quadratic_E(self,rt,rcut):
        AA_A = self.global_p.AA_dict[rt][0]
        AA_B = self.global_p.AA_dict[rt][1]
        AB_A = self.global_p.AB_dict[rt][0]
        AB_B = self.global_p.AB_dict[rt][1]
        BB_A = self.global_p.BB_dict[rt][0]
        BB_B = self.global_p.BB_dict[rt][1]
        rcut2 = rcut*rcut
        rt2 = rt*rt
        Etot = 0.0
        for i in range(self.global_p.Ntot):
            xi,yi,zi = self.xyz[i]
            for j in range(i+1,self.global_p.Ntot):
                xj,yj,zj = self.xyz[j]
                dx = xi-xj
                dy = yi-yj
                dz = zi-zj
                dx,dy,dz = self.NIC(dx,dy,dz)
                dr2 = dx*dx + dy*dy + dz*dz
                if dr2 <= rt2:
                    if self.global_p.part_dict[i] == 'A' and self.global_p.part_dict[j] == 'A':
                        self.numevals_soft += 1
                        Etot += AA_A - AA_B*dr2
                    elif self.global_p.part_dict[i] == 'A' and self.global_p.part_dict[j] == 'B' or self.global_p.part_dict[i] == 'B' and self.global_p.part_dict[j] == 'A':
                        self.numevals_soft += 1
                        Etot += AB_A - AB_B*dr2
                    elif self.global_p.part_dict[i] == 'B' and self.global_p.part_dict[j] == 'B':
                        self.numevals_soft += 1
                        Etot += BB_A - BB_B*dr2
                elif dr2 > rt2 and dr2 <= rcut2:
                    if self.global_p.part_dict[i] == 'A' and self.global_p.part_dict[j] == 'A':
                        self.numevals_LJ += 1
                        Etot += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                    elif self.global_p.part_dict[i] == 'A' and self.global_p.part_dict[j] == 'B' or self.global_p.part_dict[i] == 'B' and self.global_p.part_dict[j] == 'A':
                        self.numevals_LJ += 1
                        Etot += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                    elif self.global_p.part_dict[i] == 'B' and self.global_p.part_dict[j] == 'B':
                        self.numevals_LJ += 1
                        Etot += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
        return Etot

    def single_quadratic_E(self,part_num):
        rcut2 = self.rcut2
        rt2 = self.rt2
        dE = 0.0
        xi,yi,zi = self.xyz[part_num]
        for j in range(self.global_p.Ntot):
            if j != part_num:
                xj,yj,zj = self.xyz[j]
                dx = xi-xj
                dy = yi-yj
                dz = zi-zj
                dx,dy,dz = self.NIC(dx,dy,dz)
                dr2 = dx*dx + dy*dy + dz*dz
                if dr2 <= rt2:
                    if self.global_p.part_dict[part_num] == 'A' and self.global_p.part_dict[j] == 'A':
                        self.numevals_soft += 1
                        dE += self.AA_A - self.AA_B*dr2
                    elif self.global_p.part_dict[part_num] == 'A' and self.global_p.part_dict[j] == 'B' or self.global_p.part_dict[part_num] == 'B' and self.global_p.part_dict[j] == 'A':
                        self.numevals_soft += 1
                        dE += self.AB_A - self.AB_B*dr2
                    elif self.global_p.part_dict[part_num] == 'B' and self.global_p.part_dict[j] == 'B':
                        self.numevals_soft += 1
                        dE += self.BB_A - self.BB_B*dr2
                elif dr2 > rt2 and dr2 <= rcut2:
                    if self.global_p.part_dict[part_num] == 'A' and self.global_p.part_dict[j] == 'A':
                        self.numevals_LJ += 1
                        dE += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                    elif self.global_p.part_dict[part_num] == 'A' and self.global_p.part_dict[j] == 'B' or self.global_p.part_dict[part_num] == 'B' and self.global_p.part_dict[j] == 'A':
                        self.numevals_LJ += 1
                        dE += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                    elif self.global_p.part_dict[part_num] == 'B' and self.global_p.part_dict[j] == 'B':
                        self.numevals_LJ += 1
                        dE += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
#        print 'sep: '+str(self.separation(0,1))
#        print 'energy: '+str(dE)
        return dE

    def metropolis(self):
#        parti = randint(0,self.global_p.Ntot-1)
        parti = 0
        E_before = self.single_quadratic_E(parti)
        dx = (random()-0.5)*self.global_p.max_disp
        dy = (random()-0.5)*self.global_p.max_disp
        dz = (random()-0.5)*self.global_p.max_disp
#        dy = 0.0
#        dz = 0.0
        oldx = self.xyz[parti,0]
        oldy = self.xyz[parti,1]
        oldz = self.xyz[parti,2]
#        print self.xyz[parti]
        self.xyz[parti,0] += dx
        self.xyz[parti,1] += dy
        self.xyz[parti,2] += dz
        self.wrap_xyz(parti,self.xyz[parti,0],self.xyz[parti,1],self.xyz[parti,2])
#        print self.xyz[parti]
        E_after = self.single_quadratic_E(parti)
        if self.xyz[parti,0] > self.global_p.xmax or self.xyz[parti,0] < self.global_p.xmin:
            E_after = 100000000.0
        if self.xyz[parti,1] > self.global_p.ymax or self.xyz[parti,1] < self.global_p.ymin:
            E_after = 100000000.0
        if self.xyz[parti,2] > self.global_p.zmax or self.xyz[parti,2] < self.global_p.zmin:
            E_after = 100000000.0
        dE = E_after - E_before
        if dE < 0.0:
            self.currE += dE
        elif dE >= 0.0:
            rand_test = random()
            boltz_fact = math.exp(-self.global_p.beta*dE)
            if rand_test < boltz_fact:
                self.currE += dE
            else:
                self.xyz[parti,0] = oldx
                self.xyz[parti,1] = oldy 
                self.xyz[parti,2] = oldz
#                self.wrap_xyz(parti,self.xyz[parti,0],self.xyz[parti,1],self.xyz[parti,2])

class Sim:
    def __init__(self,steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB):
        self.params = Sim_param()
        self.params.boxl = boxl
        self.params.beta = 1.0
        self.params.NA = NA
        self.params.NB = NB
        self.params.Ntot = NA+NB
        self.params.max_disp = 0.2
        self.params.epsA = epsA
        self.params.sigA = sigA
        self.params.epsB = epsB
        self.params.sigB = sigB
        self.params.epsAB = math.sqrt(epsA*epsB)
        self.params.sigAB = (sigA+sigB)/2.
        self.params.sigA6 = self.params.sigA**6.
        self.params.sigB6 = self.params.sigB**6.
        self.params.sigAB6 = self.params.sigAB**6.
        self.params.sigA12 = self.params.sigA**12.
        self.params.sigB12 = self.params.sigB**12.
        self.params.sigAB12 = self.params.sigAB**12.
#        print 'sigma AB: '+str(self.params.sigAB)
        self.params.rcut_base = boxl/2.
        self.params.part_dict = {}
        self.params.AA_dict = {}
        self.params.AB_dict = {}
        self.params.BB_dict = {}
        for i in range(self.params.NA):
            self.params.part_dict[i] = 'A'
        for i in range(self.params.NA,self.params.NA+self.params.NB):
            self.params.part_dict[i] = 'B'
        self.rt_list = [row[0] for row in pot_arr]     #rt layer list
        self.rcut_list = [row[1] for row in pot_arr]   #rcut layer list
        self.steps_list = steps_arr                    #nmcsteps layer list
        self.num_layers = len(self.steps_list)         #number of layers in sim
        self.last_layer = self.num_layers-1            #number of the final layer

        self.xyz = np.zeros( (self.params.Ntot,3) , dtype = float) #Array to hold all particle coordinates
        self.initialize()                              #Initialize random particle positions
        self.compute_quad_param()                      #Compute all quadratic parameters for soft potential
        self.layers = []                               #Setup CAPS layers with same xyz initialized in each
        myxyz = np.copy(self.xyz)
        for i in range(self.num_layers):
            self.layers.append(Layer(i,steps_arr[i],pot_arr[i][0],pot_arr[i][1],myxyz,self.params))

    def compute_quad_param(self):
        #First entry is A, second entry is B
        #iterate over this whole range of rt
        for rt in self.rt_list:
            sigA_o_rt = self.params.sigA/rt
            sigA_o_rt3 = sigA_o_rt*sigA_o_rt*sigA_o_rt
            sigA_o_rt6 = sigA_o_rt3*sigA_o_rt3
            sigA_o_rt12 = sigA_o_rt6*sigA_o_rt6
            sigB_o_rt = self.params.sigB/rt
            sigB_o_rt3 = sigB_o_rt*sigB_o_rt*sigB_o_rt
            sigB_o_rt6 = sigB_o_rt3*sigB_o_rt3
            sigB_o_rt12 = sigB_o_rt6*sigB_o_rt6
            sigAB_o_rt = self.params.sigAB/rt
            sigAB_o_rt3 = sigAB_o_rt*sigAB_o_rt*sigAB_o_rt
            sigAB_o_rt6 = sigAB_o_rt3*sigAB_o_rt3
            sigAB_o_rt12 = sigAB_o_rt6*sigAB_o_rt6
            B_AA = -2.*self.params.epsA*(6.*sigA_o_rt6/(rt*rt) - 12.*sigA_o_rt12/(rt*rt))
            B_AB = -2.*self.params.epsAB*(6.*sigAB_o_rt6/(rt*rt) - 12.*sigAB_o_rt12/(rt*rt))
            B_BB = -2.*self.params.epsB*(6.*sigB_o_rt6/(rt*rt) - 12.*sigB_o_rt12/(rt*rt))
            #might need to add 0.25 back into these lines              
            A_AA = 4.*self.params.epsA*(sigA_o_rt12 - sigA_o_rt6 + 0.25) + B_AA*rt*rt
            A_AB = 4.*self.params.epsAB*(sigAB_o_rt12 - sigAB_o_rt6 + 0.25) + B_AB*rt*rt
            A_BB = 4.*self.params.epsB*(sigB_o_rt12 - sigB_o_rt6 + 0.25) + B_BB*rt*rt
            self.params.AA_dict[np.round(rt,2)] = [A_AA,B_AA]
            self.params.AB_dict[np.round(rt,2)] = [A_AB,B_AB]
            self.params.BB_dict[np.round(rt,2)] = [A_BB,B_BB]

    def NIC(self,dx,dy,dz):
        boxl = self.params.boxl
        if abs(dx) > boxl/2.:
            dx = abs(boxl-abs(dx))
        if abs(dy) > boxl/2.:
            dy = abs(boxl-abs(dy))
        if abs(dz) > boxl/2.:
            dz = abs(boxl-abs(dz))
        return dx,dy,dz

    def initialize_pinhole(self):
        self.params.NA = 1
        self.params.NB = 20
        self.params.Ntot = self.params.NA + self.params.NB
        for i in range(self.params.NA):
            self.params.part_dict[i] = 'A'
        for i in range(self.params.NA,self.params.NA+self.params.NB):
            self.params.part_dict[i] = 'B'

        self.xyz = np.zeros( (self.params.NB+self.params.NA,3) , dtype = float) #Array to hold all particle coordinates
        xoffset = 5.0
        yoffset = 5.0
        zoffset = 5.0
        space = 1.25
        dl = space/2.
        self.params.xmin = xoffset-1.0
        self.params.xmax = xoffset+5.0
        self.params.ymax = yoffset+1.1*dl
        self.params.ymin = yoffset-1.1*dl
        self.params.zmax = zoffset+1.1*dl
        self.params.zmin = zoffset-1.1*dl
        self.xyz[0,0] = -1.0+xoffset
        self.xyz[0,1] = 0.0+yoffset
        self.xyz[0,2] = 0.0+zoffset
        for i in range(self.params.NB/4):
            self.xyz[1+i*4+0,0] = i*1.0+xoffset
            self.xyz[1+i*4+0,1] = -dl+yoffset
            self.xyz[1+i*4+0,2] = -dl+zoffset
            self.xyz[1+i*4+1,0] = i*1.0+xoffset
            self.xyz[1+i*4+1,1] = -dl+yoffset
            self.xyz[1+i*4+1,2] = dl+zoffset
            self.xyz[1+i*4+2,0] = i*1.0+xoffset
            self.xyz[1+i*4+2,1] = dl+yoffset
            self.xyz[1+i*4+2,2] = -dl+zoffset
            self.xyz[1+i*4+3,0] = i*1.0+xoffset
            self.xyz[1+i*4+3,1] = dl+yoffset
            self.xyz[1+i*4+3,2] = dl+zoffset

    def initialize(self):
        #Initialize all particles positions in the box
        init_sep_2 = 0.81
#        self.xyz[0,0] = 2.0
#        self.xyz[0,1] = 2.0
#        self.xyz[0,2] = 2.0
#        self.xyz[1,0] = 2.0
#        self.xyz[1,1] = 2.0
#        self.xyz[1,2] = 2.95
        print "initializing particle positions to be non-overlapping..."
        self.xyz[0,0] = self.params.boxl/2.
        self.xyz[0,1] = self.params.boxl/2.
        self.xyz[0,2] = self.params.boxl/2.
        #Stupid algorithm that won't be efficient for high densities & large particle number
        #Prevents particle overlaps in initial conditions
        for i in range(1,self.params.Ntot):
#            print i
            check = False
            while check == False:
                check_list = []
                randx = random()*self.params.boxl
                randy = random()*self.params.boxl
                randz = random()*self.params.boxl
                self.xyz[i,0] = randx
                self.xyz[i,1] = randy
                self.xyz[i,2] = randz
                for j in range(0,i):
                    dx = self.xyz[j,0]-self.xyz[i,0]
                    dy = self.xyz[j,1]-self.xyz[i,1]
                    dz = self.xyz[j,2]-self.xyz[i,2]
                    dx,dy,dz = self.NIC(dx,dy,dz)
                    dr2 = dx*dx + dy*dy + dz*dz
                    if dr2 > init_sep_2:
                        check_list.append(True)
                    else:
                        check_list.append(False)
                if all(check_list) == True:
                    check = True
                else:
                    check = False
        print "finished particle initialization."

    def metropolis_2(self,layer0,layer1):
        print 'checking against previous layer....\n\n'
        beta = self.params.beta
        #THIS ALMOST CERTAINLY ISN'T RIGHT. RECHECK IT.        
        E_xf_n1 = self.layers[layer1].full_quadratic_E(self.layers[layer1].rt,self.layers[layer1].rcut)
#        E_xf_n1 = self.layers[layer1].currE
        print "trial E in layer: "+str(layer1)+" "+str(E_xf_n1)
        E_xi_n1 = self.layers[layer0].full_quadratic_E(self.layers[layer1].rt,self.layers[layer1].rcut)
        print "old E in layer: "+str(layer1)+" "+str(E_xi_n1)
        E_xf_n0 = self.layers[layer1].full_quadratic_E(self.layers[layer0].rt,self.layers[layer0].rcut)
        print "trial E in layer: "+str(layer0)+" "+str(E_xf_n0)
#        E_xi_n0 = self.layers[layer0].currE
        E_xi_n0 = self.layers[layer0].full_quadratic_E(self.layers[layer0].rt,self.layers[layer0].rcut)
        print "old E in layer: "+str(layer0)+" "+str(E_xi_n0)
        deltaE0 = E_xf_n0-E_xi_n0
        deltaE1 = E_xf_n1-E_xi_n1
        if E_xf_n0 < E_xi_n0:
            self.layers[layer0].xyz = np.copy(self.layers[layer1].xyz)
            print 'accept interlayer'
        else:
            rand_num = random()
            deltadeltaE = deltaE0-deltaE1
            if -(deltadeltaE) > 100000.0:
                deltadeltaE = 100000.0
            prob = math.exp(-beta*(deltadeltaE))
            if rand_num < prob:
                E_xi_n0 = E_xf_n0
                self.layers[layer0].xyz = np.copy(self.layers[layer1].xyz)
                print 'accept interlayer'
            else:
                print 'reject interlayer'
                #nothing

    def write_xyz(self,layer,filename):
        with open(filename,'w') as f:
            f.write(str(self.params.Ntot)+"\n\n")
#            print self.params.Ntot
            for i in range(self.params.Ntot):
                type = self.params.part_dict[i]
                if type == 'A':
                    type = 'C'
                elif type == 'B':
                    type = 'O'
                f.write(type+"\t"+str(self.layers[layer].xyz[i,0])+"\t"+str(self.layers[layer].xyz[i,1])+"\t"+str(self.layers[layer].xyz[i,2])+"\n")

    def read_xyz(self,filename):
        this_xyz = np.zeros( (self.params.Ntot,3) , dtype = float)
        with open(filename,'r') as f:
            count = 0
            for i,line in enumerate(f):
                if i > 1:
                    templine = line.split()
                    this_xyz[count,0] = float(templine[1])
                    this_xyz[count,1] = float(templine[2])
                    this_xyz[count,2] = float(templine[3])
                    count += 1
        for j in range(self.num_layers):
            self.layers[j].xyz = np.copy(this_xyz)

    def run_CAPS_LJ(self,level):
        if level == 0 and self.last_layer == 0:
            for j in range(self.layers[level].nsteps):
#                print 'iterating in final layer '+str(level)
                if j%100 == 0:
                    print j
                    print 'E: '+str(self.layers[level].currE)
                self.layers[level].E_list.append(self.layers[level].currE)
                self.layers[level].metropolis()
#                print self.layers[level].xyz[0,0]
                self.layers[level].xyz_hist.append(self.layers[level].xyz[0,0])
#                self.layers[level].sep_hist.append(self.layers[level].separation(0,1))
        elif level == 0 and level != self.last_layer:
#            print "full energy in layer "+str(level)+": "+str(self.layers[level].currE)
            for i in range(self.layers[level].nsteps):
#                print 'iteration '+str(i)+' in layer '+str(level)
                self.run_CAPS_LJ(level+1)
#                self.layers[level].xyz_hist.append(self.layers[level].xyz)
                self.layers[level].xyz_hist.append(self.layers[level].xyz[0,0])
        elif level != 0 and level != self.last_layer:
#            print "full energy in layer "+str(level)+": "+str(self.layers[level].currE)
            for i in range(self.layers[level].nsteps):
#                print 'iteration '+str(i)+' in layer '+str(level)
                self.run_CAPS_LJ(level+1)
#                self.layers[level].xyz_hist.append(self.layers[level].xyz)
                self.layers[level].xyz_hist.append(self.layers[level].xyz[0,0])
            self.layers[level-1].att_count += 1
            self.metropolis_2(level-1,level)
#            if self.layers[level-1].xyz == self.layers[level].xyz:
#                self.layers[level-1].acc_count += 1
        elif level == self.last_layer:
            self.layers[level].currE = self.layers[level].full_quadratic_E(self.layers[level].rt,self.layers[level].rcut)
#            print "full energy in layer 1: "+str(self.layers[level].currE)
#            print 'iterating in final layer '+str(level)
            for j in range(self.layers[level].nsteps):
                self.layers[level].metropolis()
#                print 'layer 0: '+str(self.layers[0].currE)
#                print 'layer 1: '+str(self.layers[1].currE)
#                self.layers[level].sep_hist.append(self.layers[level].separation(0,1))
            self.layers[level-1].att_count += 1
            self.metropolis_2(level-1,level)
#            self.layers[level-1].sep_hist.append(self.layers[level-1].separation(0,1))

