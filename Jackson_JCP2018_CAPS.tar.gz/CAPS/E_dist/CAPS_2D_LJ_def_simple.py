import numpy as np
from random import random
from random import randint
import copy as c
import matplotlib.pyplot as plt
import math
import time
import sys

#class for carrying the global simulation parameters that don't vary from layer to layer
class Sim_param:
    def __init__(self):
        self.boxl = 0
        self.NA = 0
        self.NB = 0
        self.Ntot = 0
        self.max_disp = 0.0
#        self.beta = 100000.0
        self.beta = 1.11111
        self.epsA = 0.0
        self.sigA = 0.0
        self.epsB = 0.0
        self.sigB = 0.0
        self.epsAB = 0.0
        self.sigAB = 0.0
        self.sigA6 = 0.0
        self.sigB6 = 0.0
        self.sigAB6 = 0.0
        self.sigA12 = 0.0
        self.sigB12 = 0.0
        self.sigAB12 = 0.0
        self.rcut_base = 0.0
        self.part_dict = {}
        self.AA_dict = {}
        self.AB_dict = {}
        self.BB_dict = {}

    def __del__(self):
        print("deleted")

#class for carrying the specific xy and parameters for a specific layer
class Layer:
    def __init__(self,num,steps,rt,rcut,xy,params):
        self.pot_calls = 0
        self.layer_num = num
        self.nsteps = steps
        self.numevals_LJ = 0
        self.numevals_soft = 0
        self.rt = rt
        self.rcut = rcut
        self.E_list = []
        self.E_sum = 0.0
        self.P_sum = 0.0
        self.count_sum = 0.0
        self.att_count = 0
        self.acc_count = 0
        if self.rt != 'exact':
            self.rt2 = self.rt*self.rt
        self.rcut2 = self.rcut*self.rcut
        self.rcut6 = self.rcut2*self.rcut2*self.rcut2
        self.rcut12 = self.rcut6*self.rcut6
        self.global_p = Sim_param()
        self.global_p = params
        self.xy = np.copy(xy)
        if self.rt != 'exact':
            self.AA_A = self.global_p.AA_dict[self.rt][0]
            self.AA_B = self.global_p.AA_dict[self.rt][1]
            self.AB_A = self.global_p.AB_dict[self.rt][0]
            self.AB_B = self.global_p.AB_dict[self.rt][1]
            self.BB_A = self.global_p.BB_dict[self.rt][0]
            self.BB_B = self.global_p.BB_dict[self.rt][1]
        self.Es,self.Ps = self.full_quadratic_E_P(self.rt,self.rcut)
        self.Et = self.Es
        self.Pt = self.Ps
#        print "Energy in layer "+str(self.layer_num)+": "+str(self.Es)

    #LJ cut shifted potential
    def LJ_pot(self,eps,sig6,sig12,r2):
        r6 = r2*r2*r2
        r12 = r6*r6
        return 4.*eps*(sig12/r12 - sig6/r6)#- sig12/self.rcut12 + sig6/self.rcut6)

    def LJ_press(self,eps,sig6,sig12,r2):
        r = math.sqrt(r2)
        r6 = r2*r2*r2
        r7 = r6*r
        r12 = r6*r6
        r13 = r12*r
        return r*4.*eps*((6.0*sig6/r7)-(12.0*sig12/r13))

    #If LJ particle leaves box, wrap it back around to the other side
    def wrap_xyz(self,xy):
        boxl = self.global_p.boxl
        if xy[0] > boxl:
            xy[0] -= boxl
        elif xy[0] < 0:
            xy[0] += boxl
        if xy[1] > boxl:
            xy[1] -= boxl
        elif xy[1] < 0:
            xy[1] += boxl
        return xy

    #In finding neighboring particles, implement the nearest image convention
    def NIC(self,dx,dy):
        boxl = self.global_p.boxl
        if dx > boxl/2.:
            dx -= boxl
        elif dx <= -boxl/2.:
            dx += boxl
        if dy > boxl/2.:
            dy -= boxl
        elif dy <= -boxl/2.:
            dy += boxl
        return dx,dy

    #Compute the full system energy by looping over N^2 particles
    def full_quadratic_E_P(self,rt,rcut):
        rcut2 = rcut*rcut
        Etot = 0.0
        Ptot = 0.0
        #If using the exact LJ potential and not the excluded-volume tempered potential
        if rt == 'exact':
            for i in range(self.global_p.Ntot):
                xi,yi = self.xy[i]
                type1 = self.global_p.part_dict[i]
                for j in range(i+1,self.global_p.Ntot):
                    xj,yj = self.xy[j]
                    dx = xj-xi
                    dy = yj-yi
                    dx,dy = self.NIC(dx,dy)
                    dr2 = dx*dx + dy*dy
                    type2 = self.global_p.part_dict[j]
                    sign = 0.0
                    if dx <= 0.0 and dy <= 0.0:
                        sign = 1.0
                    elif dx < 0.0 and dy >= 0.0 or dx >= 0.0 and dy < 0.0:
                        sign = -1.0
                    elif dx >= 0.0 and dy >= 0.0:
                        sign = 1.0
                    if dr2 <= rcut2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
            return Etot,Ptot
        #If using the excluded-volume tempered potential
        else:
            AA_A = self.global_p.AA_dict[rt][0]
            AA_B = self.global_p.AA_dict[rt][1]
            AB_A = self.global_p.AB_dict[rt][0]
            AB_B = self.global_p.AB_dict[rt][1]
            BB_A = self.global_p.BB_dict[rt][0]
            BB_B = self.global_p.BB_dict[rt][1]
            rt2 = rt*rt
            for i in range(self.global_p.Ntot):
                xi,yi = self.xy[i]
                type1 = self.global_p.part_dict[i]
                for j in range(i+1,self.global_p.Ntot):
                    xj,yj = self.xy[j]
                    dx = xj-xi
                    dy = yj-yi
                    dx,dy = self.NIC(dx,dy)
                    dr2 = dx*dx + dy*dy
                    type2 = self.global_p.part_dict[j]
                    if dx <= 0.0 and dy <= 0.0:
                        sign = 1.0
                    elif dx < 0.0 and dy >= 0.0 or dx >= 0.0 and dy < 0.0:
                        sign = -1.0
                    elif dx >= 0.0 and dy >= 0.0:
                        sign = 1.0
                    if dr2 <= rt2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_soft += 1
                            Etot += AA_A - AA_B*dr2
                            Ptot += sign*2.0*AA_B*math.sqrt(dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_soft += 1
                            Etot += AB_A - AB_B*dr2
                            Ptot += sign*2.0*AB_B*math.sqrt(dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_soft += 1
                            Etot += BB_A - BB_B*dr2
                            Ptot += sign*2.0*BB_B*math.sqrt(dr2)
                    elif dr2 > rt2 and dr2 <= rcut2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_LJ += 1
                            Etot += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
                            Ptot += sign*self.LJ_press(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
            return Etot,Ptot

    def single_quadratic_E_P(self,part_num):
        dE = 0.0
        dP = 0.0
        xi,yi = self.xy[part_num]
        type1 = self.global_p.part_dict[part_num]   #Particle type i for LJ parameters
        #If using the exact LJ potential and not the excluded-volume tempered potential
        if self.rt == 'exact':
            for j in range(self.global_p.Ntot):
                if j != part_num:
                    xj,yj = self.xy[j]
                    dx = xj-xi
                    dy = yj-yi
                    dx,dy = self.NIC(dx,dy)   #Nearest image convention
                    dr2 = dx*dx + dy*dy
                    type2 = self.global_p.part_dict[j]  #Particle type j for LJ parameters
                    sign = 0.0
                    if dx <= 0.0 and dy <= 0.0:
                        sign = 1.0
                    elif dx < 0.0 and dy >= 0.0 or dx >= 0.0 and dy < 0.0:
                        sign = -1.0
                    elif dx >= 0.0 and dy >= 0.0:
                        sign = 1.0
                    if dr2 <= self.rcut2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
            return dE,dP
        #If using the excluded-volume tempered potential
        else:
            rt2 = self.rt2
            for j in range(self.global_p.Ntot):
                if j != part_num:
                    type2 = self.global_p.part_dict[j]
                    xj,yj = self.xy[j]
                    dx = xj-xi
                    dy = yj-yi
                    dx,dy = self.NIC(dx,dy)
                    dr2 = dx*dx + dy*dy
                    if dx <= 0.0 and dy <= 0.0:
                        sign = 1.0
                    elif dx < 0.0 and dy >= 0.0 or dx >= 0.0 and dy < 0.0:
                        sign = -1.0
                    elif dx >= 0.0 and dy >= 0.0:
                        sign = 1.0
                    if dr2 <= rt2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_soft += 1
                            dE += self.AA_A - self.AA_B*dr2
                            dP += sign*2.0*self.AA_B*math.sqrt(dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_soft += 1
                            dE += self.AB_A - self.AB_B*dr2
                            dP += sign*2.0*self.AB_B*math.sqrt(dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_soft += 1
                            dE += self.BB_A - self.BB_B*dr2
                            dP += sign*2.0*self.BB_B*math.sqrt(dr2)
                    elif dr2 > rt2 and dr2 <= self.rcut2:
                        self.pot_calls += 1
                        if type1 == 'A' and type2 == 'A':
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsA,self.global_p.sigA6,self.global_p.sigA12,dr2)
                        elif (type1 == 'A' and type2 == 'B') or (type1 == 'B' and type2 == 'A'):
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsAB,self.global_p.sigAB6,self.global_p.sigAB12,dr2)
                        elif type1 == 'B' and type2 == 'B':
                            self.numevals_LJ += 1
                            dE += self.LJ_pot(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
                            dP += sign*self.LJ_press(self.global_p.epsB,self.global_p.sigB6,self.global_p.sigB12,dr2)
            return dE,dP

    def metropolis(self):
#        print 'INSIDE OF METROPOLIS 1 LOOP\n'
        self.att_count += 1.0
        parti = randint(0,self.global_p.Ntot-1)
        E_before,P_before = self.single_quadratic_E_P(parti)
        dx = (random()-0.5)*self.global_p.max_disp
        dy = (random()-0.5)*self.global_p.max_disp
        oldx,oldy = self.xy[parti]
        newx = oldx + dx
        newy = oldy + dy
        newx,newy = self.wrap_xyz([newx,newy])
        self.xy[parti,0] = newx
        self.xy[parti,1] = newy
        E_after,P_after = self.single_quadratic_E_P(parti)
        dE = E_after - E_before
        dP = P_after - P_before
        self.Et += dE
        self.Pt += dP
        if self.Et < self.Es:
            self.Es = self.Et
            self.Ps = self.Pt
            self.acc_count += 1
            self.xy[parti,0] = newx
            self.xy[parti,1] = newy
        elif self.Et >= self.Es:
            rand_test = random()
            boltz_fact = math.exp(-self.global_p.beta*dE)
            if rand_test < boltz_fact:
                self.Es = self.Et
                self.Ps = self.Pt
                self.acc_count += 1
                self.xy[parti,0] = newx
                self.xy[parti,1] = newy
            else:
                self.Et = self.Es
                self.Pt = self.Ps
                self.xy[parti,0] = oldx
                self.xy[parti,1] = oldy

class Sim:
    def __init__(self,steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB,loaded=''):
        self.params = Sim_param()
        self.params.boxl = boxl
        self.params.area = boxl*boxl
        self.params.volume = boxl*boxl*boxl
#        self.params.beta = 100000.0
        self.params.beta = 1.11111
        self.params.NA = NA
        self.params.NB = NB
        self.params.Ntot = NA+NB
        self.params.max_disp = 1.0
        self.params.epsA = epsA
        self.params.sigA = sigA
        self.params.epsB = epsB
        self.params.sigB = sigB
        self.params.epsAB = 1.5
        self.params.sigAB = 0.8
        self.params.sigAB6 = 0.8**6.
        self.params.sigAB12 = 0.8**12.
#        self.params.epsAB = math.sqrt(epsA*epsB)
#        self.params.sigAB = (sigA+sigB)/2.
        self.params.sigA6 = self.params.sigA**6.
        self.params.sigB6 = self.params.sigB**6.
#        self.params.sigAB6 = self.params.sigAB**6.
        self.params.sigA12 = self.params.sigA**12.
        self.params.sigB12 = self.params.sigB**12.
#        self.params.sigAB12 = self.params.sigAB**12.
        self.params.rcut_base = boxl/2.
        self.dr = 0.1
        self.params.part_dict = {}
        self.params.AA_dict = {}
        self.params.AB_dict = {}
        self.params.BB_dict = {}
        for i in range(self.params.NA):
            self.params.part_dict[i] = 'A'
        for i in range(self.params.NA,self.params.NA+self.params.NB):
            self.params.part_dict[i] = 'B'
        self.rt_list = [row[0] for row in pot_arr]
        self.rcut_list = [row[1] for row in pot_arr]
        self.steps_list = steps_arr
        self.num_layers = len(self.steps_list)
        self.last_layer = self.num_layers-1
        self.xy = np.zeros( (self.params.Ntot,2) , dtype = float)
        if loaded != '':
            self.load_xy(loaded)
        else:
            self.initialize()
        self.compute_quad_param()
        self.layers = []
        #myxy = np.copy(self.xy)
        for i in range(self.num_layers):
            self.layers.append(Layer(i,steps_arr[i],pot_arr[i][0],pot_arr[i][1],self.xy,self.params))
#        print self.layers[0].xy[0]
#        self.layers[0].xy[0] = np.array([0.2,0.2])
#        print self.layers[0].xy[0]
#        print self.layers[1].xy[0]
#        sys.exit()
        if self.num_layers == 1:
            self.print_reg = self.params.Ntot*10
        else:
            self.print_reg = 1
        self.save_size = self.steps_list[0]/self.print_reg
#        print('saving ',self.save_size,' snapshots...')
#        if self.num_layers == 1:
#            self.RDF_track = np.zeros( (self.save_size,int(self.params.rcut_base/self.dr)+1) , dtype = float)
#            self.RDF_arr = np.arange(0,self.params.rcut_base+self.dr,self.dr)
#        else:
#            self.RDF_track = np.zeros( (self.save_size,int(self.params.rcut_base/self.dr)+1) , dtype = float)
#            self.RDF_arr = np.arange(0,self.params.rcut_base+self.dr,self.dr)

    def compute_quad_param(self):
        #First entry is  A, second entry is B
        #iterate over this whole range of rt
        for rt in self.rt_list:
            if rt != 'exact':                
                sigA_o_rt = self.params.sigA/rt
                sigA_o_rt3 = sigA_o_rt*sigA_o_rt*sigA_o_rt
                sigA_o_rt6 = sigA_o_rt3*sigA_o_rt3
                sigA_o_rt12 = sigA_o_rt6*sigA_o_rt6
                sigB_o_rt = self.params.sigB/rt
                sigB_o_rt3 = sigB_o_rt*sigB_o_rt*sigB_o_rt
                sigB_o_rt6 = sigB_o_rt3*sigB_o_rt3
                sigB_o_rt12 = sigB_o_rt6*sigB_o_rt6
                sigAB_o_rt = self.params.sigAB/rt
                sigAB_o_rt3 = sigAB_o_rt*sigAB_o_rt*sigAB_o_rt
                sigAB_o_rt6 = sigAB_o_rt3*sigAB_o_rt3
                sigAB_o_rt12 = sigAB_o_rt6*sigAB_o_rt6
                B_AA = -2.*self.params.epsA*(6.*sigA_o_rt6/(rt*rt) - 12.*sigA_o_rt12/(rt*rt))
                B_AB = -2.*self.params.epsAB*(6.*sigAB_o_rt6/(rt*rt) - 12.*sigAB_o_rt12/(rt*rt))
                B_BB = -2.*self.params.epsB*(6.*sigB_o_rt6/(rt*rt) - 12.*sigB_o_rt12/(rt*rt))
                A_AA = 4.*self.params.epsA*(sigA_o_rt12 - sigA_o_rt6) + B_AA*rt*rt
                A_AB = 4.*self.params.epsAB*(sigAB_o_rt12 - sigAB_o_rt6) + B_AB*rt*rt
                A_BB = 4.*self.params.epsB*(sigB_o_rt12 - sigB_o_rt6) + B_BB*rt*rt
                self.params.AA_dict[np.round(rt,2)] = [A_AA,B_AA]
                self.params.AB_dict[np.round(rt,2)] = [A_AB,B_AB]
                self.params.BB_dict[np.round(rt,2)] = [A_BB,B_BB]

    def calc_RDF_snapshot(self,snap,layer):
        rcut = self.layers[layer].rcut
        rcut2 = rcut*rcut
        boxl = self.params.boxl
        config = np.copy(self.layers[layer].xy)
        for i in range(len(config)):
            x1 = config[i,0]
            y1 = config[i,1]
            for j in range(i+1,len(config)):
                x2 = config[j,0]
                y2 = config[j,1]
                dx = x2-x1
                dy = y2-y1
                if dx > boxl/2.:
                    dx -= boxl
                elif dx < -boxl/2.:
                    dx += boxl
                if dy > boxl/2.:
                    dy -= boxl
                elif dy < -boxl/2.:
                    dy += boxl
                r2 = dx*dx + dy*dy
                if r2 < rcut2:
                    r = math.sqrt(r2)
                    rbin = int(r/self.dr)
                    self.RDF_track[snap,rbin] += 2
        self.RDF_track[snap] *= boxl*boxl
        self.RDF_track[snap] /= float(self.params.Ntot*self.params.Ntot)
        for i in range(len(self.RDF_arr)):
            norm = 2.*3.14159*self.RDF_arr[i]*self.dr
            self.RDF_track[snap,i] /= norm
                
    def NIC(self,dx,dy):
        boxl = self.params.boxl
        if abs(dx) > boxl/2.:
            dx = abs(boxl-abs(dx))
        if abs(dy) > boxl/2.:
            dy = abs(boxl-abs(dy))
        return dx,dy

    def initialize_pinhole(self):
        #initialize the moving particle
        self.xy[0,0] = -1.0
        self.xy[0,1] = 0.0
        #initialize the unmovable boundary
        #top and bottom bound

    def initialize(self):
        init_sep_2 = 0.64
#        print("initializing particle positions to be non-overlapping...")
        self.xy[0,0] = self.params.boxl/2.
        self.xy[0,1] = self.params.boxl/2.
        #Stupid algorithm that won't be efficient for high densities & large particle number
        #Prevents particle overlaps in initial conditions
        for i in range(1,self.params.Ntot):
            check = False
            while check == False:
                check_list = []
                randx = random()*self.params.boxl
                randy = random()*self.params.boxl
                self.xy[i,0] = randx
                self.xy[i,1] = randy
                for j in range(0,i):
                    dx = self.xy[j,0]-self.xy[i,0]
                    dy = self.xy[j,1]-self.xy[i,1]
                    dx,dy = self.NIC(dx,dy)
                    dr2 = dx*dx + dy*dy
                    if dr2 > init_sep_2:
                        check_list.append(True)
                    else:
                        check_list.append(False)
                if all(check_list) == True:
                    check = True
                else:
                    check = False
#        print("finished particle initialization.")

    def metropolis_2(self,level):
#        print 'checking against previous layer...\n\n'
        self.layers[level-1].att_count += 1
        beta = self.params.beta
        E_xf_n1 = self.layers[level].Es
        P_xf_n1 = self.layers[level].Ps
        E_xi_n1,P_xi_n1 = self.layers[level-1].full_quadratic_E_P(self.layers[level].rt,self.layers[level].rcut)
        E_xf_n0,P_xf_n0 = self.layers[level].full_quadratic_E_P(self.layers[level-1].rt,self.layers[level-1].rcut)
        E_xi_n0 = self.layers[level-1].Es
        P_xi_n0 = self.layers[level-1].Ps
        deltaE0 = E_xf_n0-E_xi_n0
        deltaE1 = E_xf_n1-E_xi_n1
        deltadeltaE = deltaE0-deltaE1
#        print 'status before check:\n'
#        print 'level '+str(level-1)+' xy: '+str(self.layers[level-1].xy)
#        print 'level '+str(level)+' xy: '+str(self.layers[level].xy)
#        print 'level '+str(level-1)+' Es: '+str(self.layers[level-1].Es)
#        print 'level '+str(level)+' Es: '+str(self.layers[level].Es)
#        print 'E_xf_n1: '+str(E_xf_n1)
#        print 'E_xi_n1: '+str(E_xi_n1)
#        print 'E_xf_n0: '+str(E_xf_n0)
#        print 'E_xi_n0: '+str(E_xi_n0)
#        print('deltadeltaE: '+str(deltadeltaE))
#        print deltadeltaE
        if deltadeltaE < 0:
            self.layers[level-1].acc_count += 1
            self.layers[level-1].Es = E_xf_n0
            self.layers[level-1].Ps = P_xf_n0 
            self.layers[level-1].xy = np.copy(self.layers[level].xy)
            self.layers[level].Es = E_xf_n1
            self.layers[level].Ps = P_xf_n1
#            print('accept interlayer '+str(level)+' -> '+str(level-1))
#            print 'level '+str(level-1)+' xy: '+str(self.layers[level-1].xy)
#            print 'level '+str(level)+' xy: '+str(self.layers[level].xy)
#            print 'level '+str(level-1)+' Es: '+str(self.layers[level-1].Es)
#            print 'level '+str(level)+' Es: '+str(self.layers[level].Es)
        else:
            rand_num = random()
            if deltadeltaE > 100000.0:
                deltadeltaE = 100000.0
            prob = math.exp(-beta*(deltadeltaE))
#            print('random: '+str(rand_num))
#            print 'prob: '+str(prob)
            if rand_num < prob:
                self.layers[level-1].acc_count += 1
                self.layers[level-1].Es = E_xf_n0
                self.layers[level-1].Ps = P_xf_n0
                self.layers[level-1].xy = np.copy(self.layers[level].xy)
                self.layers[level].Es = E_xf_n1
                self.layers[level].Ps = P_xf_n1
#                self.layers[level].xy = self.layers[level].xy
#                print 'level '+str(level-1)+' xy: '+str(self.layers[level-1].xy)
#                print 'level '+str(level)+' xy: '+str(self.layers[level].xy)
#                print 'level '+str(level-1)+' Es: '+str(self.layers[level-1].Es)
#                print 'level '+str(level)+' Es: '+str(self.layers[level].Es)
#                print 'accept interlayer '+str(level)+' -> '+str(level-1)
            else:                
                self.layers[level-1].Es = E_xi_n0
                self.layers[level-1].Ps = P_xi_n0
#                self.layers[level-1].xy = self.layers[level-1].xy
                self.layers[level].Es = E_xi_n1
                self.layers[level].Ps = P_xi_n1
                self.layers[level].xy = np.copy(self.layers[level-1].xy)
#                print 'level '+str(level-1)+' xy: '+str(self.layers[level-1].xy)
#                print 'level '+str(level)+' xy: '+str(self.layers[level].xy)
#                print 'level '+str(level-1)+' Es: '+str(self.layers[level-1].Es)
#                print 'level '+str(level)+' Es: '+str(self.layers[level].Es)
#                print 'reject interlayer '+str(level)+' -> '+str(level-1)

    def write_xyz(self,layer,filename):
        with open(filename,'w') as f:
            f.write(str(self.params.Ntot)+"\n\n")
            for i in range(self.params.Ntot):
                type = self.params.part_dict[i]
                if type == 'A':
                    type = 'C'
                elif type == 'B':
                    type = 'O'
                f.write(type+"\t"+str(self.layers[layer].xy[i,0])+"\t"+str(self.layers[layer].xy[i,1])+"\t 0.0 \n")

    def write_traj(self,layer):
        self.trajfile.write(str(self.params.Ntot)+"\n\n")
        for i in range(self.params.Ntot):
                type = self.params.part_dict[i]
                if type == 'A':
                    type = 'C'
                elif type == 'B':
                    type = 'O'
                self.trajfile.write(type+"\t"+str(self.layers[layer].xy[i,0])+"\t"+str(self.layers[layer].xy[i,1])+"\t 0.0 \n")

    def write_RDF_file(self,filename):
        with open(filename,'w') as f:
            for j in range(len(self.RDF_arr)):
                if j > 0:
                    f.write("{} \t {} \n".format(self.RDF_arr[j],np.mean(self.RDF_track,axis=0)[j]))

    def read_RDF_file(self,filename):
        x_arr = []
        y_arr = []
        with open(filename,'r') as f:
            for i,line in enumerate(f):
                templine = line.split()
                x_arr.append(float(templine[0]))
                y_arr.append(float(templine[1]))
        return x_arr,y_arr

    def read_xy(self,filename):
        this_xy = np.zeros( (self.params.Ntot,2) , dtype = float)
        with open(filename,'r') as f:
            count = 0
            for i,line in enumerate(f):
                if i > 1:
                    templine = line.split()
                    this_xy[count,0] = float(templine[1])
                    this_xy[count,1] = float(templine[2])
                    count += 1
            for j in range(self.num_layers):
                self.layers[j].xy = np.copy(this_xy)

    def run_CAPS_LJ(self,level):
        if level == 0 and self.last_layer == 0:
            for j in range(self.layers[level].nsteps):
                if j%(self.params.Ntot) == 0:
                    self.layers[level].E_list.append(self.layers[level].Es)
                    self.layers[level].E_sum += self.layers[level].Es
                    self.layers[level].P_sum += self.layers[level].Ps
                    self.layers[level].count_sum += 1.0
                if j%(self.print_reg) == 0:
                    print(j/self.params.Ntot)
                    Vterm = 1./(2.*self.params.area)
                    mean_E_per_part = self.layers[level].E_sum/(self.layers[level].count_sum*self.params.Ntot)
                    mean_P_per_part = Vterm*(self.layers[level].P_sum/(self.layers[level].count_sum))
#                    print('mean energy per particle: '+str(mean_E_per_part))
#                    print('mean pressure: '+str(mean_P_per_part+(self.params.Ntot/(self.params.area*self.params.beta))))
#                    self.calc_RDF_snapshot(j/self.print_reg,0)
                self.layers[level].metropolis()
        elif level == 0 and level != self.last_layer:
            for i in range(self.layers[level].nsteps):
                self.run_CAPS_LJ(level+1)
                if i%(1) == 0:
                    print(i)
                    self.print_acc_ratio()
                    self.write_xyz(level,'final.xyz')
#                    print('\nTOTAL ENERGY E: '+str(self.layers[level].Es)+"\n")
                    self.layers[level].E_list.append(self.layers[level].Es)
                    self.layers[level].E_sum += self.layers[level].Es
                    self.layers[level].P_sum += self.layers[level].Ps
                    self.layers[level].count_sum += 1.0
                if i%(self.print_reg*10) == 0:
#                    print('MC step: '+str(i))
#                    self.calc_RDF_snapshot(i/self.print_reg,0)
                    Vterm = 1./(2.*self.params.area)
                    mean_E_per_part = self.layers[level].E_sum/(self.layers[level].count_sum*self.params.Ntot)
                    mean_P_per_part = Vterm*(self.layers[level].P_sum/(self.layers[level].count_sum))
#                    print('mean_energy: '+str(mean_E_per_part))
#                    print('mean pressure: '+str(mean_P_per_part+(self.params.Ntot/(self.params.area*self.params.beta))))
        elif level != 0 and level != self.last_layer:
            for i in range(self.layers[level].nsteps):
                self.run_CAPS_LJ(level+1)
            self.metropolis_2(level)
        elif level == self.last_layer:
            for i in range(self.layers[level].nsteps):
                self.layers[level].metropolis()
            self.metropolis_2(level)

    def print_acc_ratio(self):
        for layer in self.layers:
            print("Acceptance ratio in layer "+str(layer.layer_num)+": "+str((layer.acc_count)/float(layer.att_count)))

    def print_pot_calls(self):
        tot_calls = 0
        for layer in self.layers:
            tot_calls += layer.pot_calls
            print("potential calls in layer "+str(layer.layer_num)+": "+str(layer.pot_calls))
        print("total number of pot eng calls: "+str(tot_calls))

    def load_xy(self,filename):
        with open(filename,'r') as f:
            for i,line in enumerate(f):
                if i > 1:
                    templine = line.split()
                    id = i-2
                    x = float(templine[1])
                    y = float(templine[2])
                    self.xy[id,0] = x
                    self.xy[id,1] = y

    def plot_all_potentials(self):
        for layer in self.layers:
            x = np.arange(0.1,layer.rcut,0.001)
            y = np.arange(0.1,layer.rcut,0.001)
            for xval,i in zip(x,range(len(x))):
                if layer.rt == 'exact':
                    y[i] =  layer.LJ_pot(self.params.epsA,self.params.sigA6,self.params.sigA12,xval*xval)
                else:
                    if xval < layer.rt:
                        y[i] = layer.AA_A - layer.AA_B*xval*xval
                    elif xval > layer.rt and xval < layer.rcut:
                        y[i] =  layer.LJ_pot(self.params.epsA,self.params.sigA6,self.params.sigA12,xval*xval)
            plt.plot(x,y,label=layer.layer_num,linewidth=3.0)
        plt.xlim(0.7,2.0)
        plt.xlabel('r ($\sigma$)')
        plt.ylabel('Energy ($\epsilon$)')
        plt.axhline(y=0.0,color='k',linestyle='--',linewidth=1.0)
        plt.ylim(-1.0,5.0)
        plt.legend()
        plt.show()

