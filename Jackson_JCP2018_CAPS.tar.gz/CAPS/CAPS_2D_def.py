import pes2Dgauss as pes
import numpy as np
from random import random
import matplotlib.pyplot as plt
import math
import sys

def importPES(the_pes):
    globals()['pes'] = the_pes

#Function that proposes a trial move in x
def trial_move(xy_arr,max_disp):
    test_disp_x = max_disp*(random()-0.5)
    test_disp_y = max_disp*(random()-0.5)
    xt = xy_arr[0] + test_disp_x
    yt = xy_arr[1] + test_disp_y
    return xt,yt

#Class for a given layer of the CAPS MC - Has own unique level number, number of MC steps, and potential value
class Layer:
    def __init__(self,num,steps,pot):
        self.layer_num = num                          #Layer number
        self.nsteps = steps                           #Number of MC steps within that layer
        self.coeffs = pes.load_coeffs()                                #coefficients to generate 2d surface
        self.xys = np.array([0.5,0.5])                                 #Variable to hold saved coordinate
        self.xyt = np.array([0.5,0.5])                                 #Variable to hold trial coordinate
        self.max_disp = 0.3                                            #Maximum random displacement
        self.pot = pot                                #Controls height of barriers in each layer
        self.Es = self.pot*pes.evaluate(0.0,self.xys,*self.coeffs)          #Variable to hold potential for xys
        self.Et = 0.0                                 #Variable to hold potential for xyt
        self.beta = 1.0                               #Beta temperature param for MC accept
        self.xys_hist = [self.xys]                             #Array to hold all visited configurations in this layer
        self.att_count = 0                            #Keep track of attempted MC moves in this layer
        self.acc_count = 0                            #Keep track of accepted MC moves in this layer

    #Method to run a basic Metropolis MC routine within the layer
    def metropolis(self):
#        print 'curr E:'+str(self.Es)
#        print 'curr xy:'+str(self.xys)
        self.att_count += 1
        self.xyt = trial_move(self.xys,self.max_disp)
        self.Et = self.pot*pes.evaluate(0.0,self.xyt,*self.coeffs)
#        print 'trial E:'+str(self.Et)
#        print 'trial xy:'+str(self.xyt)
        x,y = self.xyt
        trialE = self.Et
        trialxy = self.xyt
        if self.Et < self.Es:
            self.Es = trialE
            self.xys = trialxy
            self.acc_count += 1
        else:
            rand_n = random()
            prob = math.exp(-self.beta*(self.Et-self.Es))
            if rand_n < prob:
                self.Es = trialE
                self.xys = trialxy 
                self.acc_count += 1

#Class that holds all MC layers of the simulation
class Sim:
    def __init__(self,steps_arr,pot_arr):
        if len(steps_arr) != len(pot_arr):
            print('Layer input is incorrect, exiting...')
            sys.exit()
        else:
            self.coeffs = pes.load_coeffs()
            self.steps_arr = steps_arr
            self.count = 0.0
            self.pot_arr = pot_arr
            self.num_layers = len(steps_arr)
            self.first_layer = 0
            self.last_layer = self.num_layers-1
            self.layers = []
            self.hist_disc = 45
            self.E_mean = 0.0
            self.low_bound = -0.5
            self.hi_bound = 1.5
            self.disc = (self.hi_bound-self.low_bound)/float(self.hist_disc)
            self.shift = int(abs(self.low_bound)/self.disc)
            self.FEP_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            self.log_FEP_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            self.count_hist = np.zeros( (self.num_layers,self.hist_disc,self.hist_disc) , dtype = float)
            for i in range(self.num_layers):
                self.layers.append(Layer(i,steps_arr[i],pot_arr[i]))

    #Method that performs the deltaE1-deltaE0 check between MC layers of simulation
    def metropolis_2(self,level):
        beta = 1.0
        self.layers[level-1].att_count += 1.0
        layer0_C = self.layers[level-1].pot
        layer1_C = self.layers[level].pot
        E_xf_n1 = self.layers[level].pot*pes.evaluate(0.0,self.layers[level].xys,*self.coeffs)
        E_xi_n1 = self.layers[level].pot*pes.evaluate(0.0,self.layers[level-1].xys,*self.coeffs)
        E_xf_n0 = self.layers[level-1].pot*pes.evaluate(0.0,self.layers[level].xys,*self.coeffs)
        E_xi_n0 = self.layers[level-1].pot*pes.evaluate(0.0,self.layers[level-1].xys,*self.coeffs)
        deltaE0 = E_xf_n0-E_xi_n0
        deltaE1 = E_xf_n1-E_xi_n1
        rand_num = random()
        x,y = self.layers[level].xys
        xbin = int(x/self.disc) + self.shift
        ybin = int(y/self.disc) + self.shift
        self.FEP_hist[level,xbin,ybin] += math.exp(-beta*(E_xf_n0-E_xf_n1))
        self.count_hist[level,xbin,ybin] += 1.0
        prob = math.exp(-beta*(deltaE0-deltaE1))
        if rand_num <= prob:
            self.layers[level-1].acc_count += 1
            self.layers[level-1].Es = E_xf_n0
            self.layers[level-1].xys = self.layers[level].xys
            self.layers[level].Es = E_xf_n1
            self.layers[level].xys = self.layers[level].xys
        else:
            self.layers[level-1].Es = E_xi_n0
            self.layers[level-1].xys = self.layers[level-1].xys
            self.layers[level].Es = E_xi_n1
            self.layers[level].xys = self.layers[level-1].xys
    #Recursive method that runs an arbitrary number of nested loops.  This is where the meat is.

    def run_CAPS(self,level):
        #If there is only one layer, run a normal MC
        if level == 0 and self.last_layer == 0:
            for j in xrange(self.layers[level].nsteps):                
                if j%1 == 0:
                    self.count += 1.0
                    self.E_mean += float(self.pot_arr[0])*pes.evaluate(0.0,self.layers[level].xys,*self.coeffs)
                if j%1000 == 0:
                    print(j)
                    print(self.E_mean/self.count)
                self.layers[level].metropolis()            
        #If there are many layers and its the first layer,launch MC and descend to next layer
        elif level == 0 and level != self.last_layer:
            self.layers[level+1].xys = self.layers[level].xys
            for i in xrange(self.layers[level].nsteps):
                self.count += 1.0
                self.E_mean += float(self.pot_arr[0])*pes.evaluate(0.0,self.layers[level].xys,*self.coeffs)
                if i%1000 == 0:
                    print(i)
                    print(self.E_mean/self.count)
                self.run_CAPS(level+1)
       #If there are many layers and its not the first or last layer
        elif level != 0 and level != self.last_layer:
            self.layers[level+1].xys = self.layers[level].xys
            for k in xrange(self.layers[level].nsteps):
                self.run_CAPS(level+1)
            self.metropolis_2(level)
        #If there are many layers and it is the last layer
        elif level == self.last_layer:
            for j in xrange(self.layers[level].nsteps):                
                self.layers[level].metropolis()
            self.metropolis_2(level)

    def generate_hist(self,level):
        myhist = np.zeros( (self.hist_disc,self.hist_disc) , dtype = float)
        for pair in self.layers[level].xys_hist:
            x,y = pair
            xbin = int(x/self.disc)+self.shift
            ybin = int(y/self.disc)+self.shift
            myhist[xbin,ybin] += 1.
        myhist /= np.sum(myhist)
        return -1.*np.log(myhist)

    def generate_FEP_hist(self,level):
        self.FEP_hist[level] = np.divide(self.FEP_hist[level],self.count_hist[level])
        self.log_FEP_hist[level] = -1.*np.log(self.FEP_hist[level])
#        print self.log_FEP_hist[level]
#        print np.nanmax(FES),np.nanmin(FES)
        return self.log_FEP_hist[level]

    def sum_all_hist(self):
        self.FEP_sum = np.zeros( (self.hist_disc,self.hist_disc) , dtype = float)
#        self.FEP_sum = np.nansum(self.FEP_hist[1:],axis=0)
        print(self.FEP_sum.shape)
        for i in range(self.num_layers):
            for j in range(self.hist_disc):
                for k in range(self.hist_disc):
                    if math.isnan(self.FEP_hist[i,j,k]) == False:
                        self.FEP_sum[j,k] += self.log_FEP_hist[i,j,k]
        return self.FEP_sum

    def print_acc_ratio(self):
        for layer in self.layers:
            print("Acceptance ratio in layer "+str(layer.layer_num)+": "+str((layer.acc_count)/float(layer.att_count)))
