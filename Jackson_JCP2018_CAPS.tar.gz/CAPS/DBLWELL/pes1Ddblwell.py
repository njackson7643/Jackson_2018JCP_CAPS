#==================================================================
# SUPPORTING MODULES
#==================================================================
import numpy as np

#==================================================================
# CONSTANTS VARIABLES
#==================================================================
main="pes.main.dat"	# coefficient file name to describ potential
                        # only coefficients in here specify the barrier height and where the
                        # potential minima are

#==================================================================
#  AUX: isnumber
#==================================================================
def isnumber(s):
  try:
    float(s)
    return True
  except ValueError:
    return False

#==================================================================
#  AUX: numericalize
#==================================================================
def numericalize(fid):
  lines = [line.strip().split() for line in fid]
  lines = [line for line in lines if isnumber(line[0])]
  data = [[float(s) for s in line] for line in lines] # extract numerical       data
  return np.array(data)

#==================================================================
#  AUX: load_coeffs
#==================================================================
def load_coeffs():
  coeffs = []
  fid     = open(main,"r")
  coeffs  = numericalize(fid)
  return coeffs

#==================================================================
#  AUX: evaluate
#==================================================================
def evaluate(Er,r,coeffs):
  x   = r[0]		# x-coordinate
  x2  = x*x
  x4  = x2*x2
  E   = coeffs[0]
  xmin= coeffs[1]
  C   = 0.5 / xmin / xmin
  return 2.0*E/ xmin /xmin*(C*x4-x2+0.25/C) - Er


