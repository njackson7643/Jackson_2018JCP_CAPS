import pes1Ddblwell as pes
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# setting up a grid to look at the PES
nx = 500
xvec = np.linspace(-4,4,nx)
Ug = np.zeros(xvec.shape)

# first load the coefficients for PES as follows
coeffs = pes.load_coeffs()

# testing the evaluation
for i in range(nx):
     Ug[i] = pes.evaluate(0.0,[xvec[i]],*coeffs)

# Plotting the Projection
fS = 16
fig = plt.figure(figsize=(6.5,5.0),dpi=800)
plt.rcParams['mathtext.fontset'] = 'stixsans'
plt.plot(xvec,Ug,'-',linewidth=3.0)
plt.xlabel(r'x',fontsize=fS,fontweight='bold')
plt.ylabel(r'U',fontsize=fS,fontweight='bold')
plt.xlim(-4.0,4.0)
plt.ylim(0,30.0)
plt.savefig("pes.png")
