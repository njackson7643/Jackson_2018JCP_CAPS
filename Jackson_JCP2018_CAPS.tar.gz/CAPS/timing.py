import time

def LJ_pot(eps,sig6,sig12,r2):
    r6 = r2*r2*r2
    r12 = r6*r6
    return 4.*eps*(sig12/r12 - sig6/r6)

time0 = time.clock()
a = LJ_pot(1.0,1.0,1.0,0.5)
time1 = time.clock()
print 'LJ call took '+str(time1-time0)
