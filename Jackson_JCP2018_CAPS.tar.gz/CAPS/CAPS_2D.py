from CAPS_2D_def import *
import sys
sys.path = sys.path + ['/Users/nick/Box\ Sync/Work/CAPS/Rough2D']
from matplotlib import cm
import pes2Dgauss as pes
importPES(pes)

#Parameters for simulation
#step array takes the form [n0steps,n1steps,n2steps,...]
#pot array takes the form [potn0,potn1,potn2,...]
#pot_arr now takes factors by which to scale the energy (<1)
step_arr = [100000,1,3]
pot_arr = [0.1,0.05,0.03]

#Run Simulation
mysim = Sim(step_arr,pot_arr)
#mysim.layers[0].max_disp = 0.5
#mysim.layers[1].max_disp = 0.3
mysim.run_CAPS(0)
mysim.print_acc_ratio()
print("Simulation Finished")

print("average energy: ",str(mysim.E_mean/mysim.count))

layer0 = np.array(mysim.layers[0].xys_hist)
layer1 = np.array(mysim.layers[1].xys_hist)
print("layer 1:",layer1)
layer1 = layer1.reshape((step_arr[0],step_arr[1]+1,2))
if mysim.num_layers > 2:
    layer2 = np.array(mysim.layers[2].xys_hist)
    layer2 = layer2.reshape((step_arr[0],step_arr[1],step_arr[2]+1,2))


#print 'Prepping background contour plot...'
nx = 500
ny = 500
xvec = np.linspace(-0.0,1.00,nx)
yvec = np.linspace(-0.0,1.00,ny)
gx,gy = np.meshgrid(xvec,yvec)
Ug = np.zeros(gx.shape)
coeffs = pes.load_coeffs()

for i in range(nx):
    for j in range(ny):
        Ug[i,j] = pes.evaluate(0.0,[gx[i,j],gy[i,j]],*coeffs)
fS = 16
    
print 'plotting trajectory...'
ind = 0
for i in range(step_arr[0]):
    for k in range(step_arr[1]):
        plt.plot(layer0[:i+1,0],layer0[:i+1,1],'--o',linewidth=4.0,color='r',label=str(pot_arr[0]),alpha=1.0)
        plt.plot(layer1[i,:k+1,0],layer1[i,:k+1,1],'--o',linewidth=2.0,color='b',label=str(pot_arr[1]),alpha=1.0)
        if mysim.num_layers == 3:
            plt.plot(0,0,color='k',label=str(pot_arr[2]))
        plt.contourf(gx,gy,Ug,20, cmap=cm.coolwarm,alpha=0.8)
        if mysim.num_layers > 2:
            for j in range(step_arr[2]):
                basex = layer2[i,k,j][0]
                basey = layer2[i,k,j][1]
                ptx = layer2[i,k,j+1][0]
                pty = layer2[i,k,j+1][1]
                dx = ptx-basex
                dy = pty-basey
                plt.arrow(basex,basey,dx,dy,head_width=0.01,head_length=0.01,ec='k',alpha=1.0)
            plt.xlim(-0.05,1.05)
            plt.ylim(-0.05,1.05)
            plt.title("CAPS trajectory")
            plt.legend()
            plt.savefig("image_{0:03d}.png".format(ind))
            plt.close()
            print ind
            ind += 1
        plt.show()
        sys.exit()



#plt.imshow(mysim.generate_hist(0))
#plt.show()

"""
fig,ax = plt.subplots(3,2)

c_cycle = ['b','g','r','c','m','y','k','w']

#im0=ax[0,0].imshow(mysim.generate_hist(0))
#im1=ax[1,0].imshow(mysim.generate_hist(1))
#im2=ax[0,1].imshow(mysim.generate_hist(2))
#im3=ax[1,1].imshow(mysim.generate_hist(3))
#im2=ax[2,1].imshow(mysim.generate_hist(4))
#im0=ax[0,0].imshow(mysim.generate_FEP_hist(0))
im1=ax[1,0].imshow(mysim.generate_FEP_hist(1))
im2=ax[0,1].imshow(mysim.generate_FEP_hist(2))
im3=ax[1,1].imshow(mysim.generate_FEP_hist(3))
im4=ax[2,1].imshow(mysim.generate_FEP_hist(4))
im5=ax[2,0].imshow(mysim.sum_all_hist())
#ax[0,0].colorbar()
#ax[1,0].colorbar()
#ax[0,1].colorbar()

#fig.colorbar(im0,ax=ax[0,0])
fig.colorbar(im1,ax=ax[1,0])
fig.colorbar(im2,ax=ax[0,1])
fig.colorbar(im3,ax=ax[1,1])
fig.colorbar(im4,ax=ax[2,1])
fig.colorbar(im5,ax=ax[2,0])
ax[0,0].invert_yaxis()
ax[1,0].invert_yaxis()
ax[0,1].invert_yaxis()
ax[1,1].invert_yaxis()
ax[2,1].invert_yaxis()
ax[2,0].invert_yaxis()
ax[0,0].set_title('layer 0')
ax[1,0].set_title('layer 1')
ax[0,1].set_title('layer 2')
ax[1,1].set_title('layer 3')
ax[2,1].set_title('layer 4')
ax[2,0].set_title('FEP Approx FES')
plt.tight_layout()
plt.show()

"""
