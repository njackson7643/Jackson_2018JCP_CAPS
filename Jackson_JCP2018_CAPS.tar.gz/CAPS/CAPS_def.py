import numpy as np
from random import random
import matplotlib.pyplot as plt
import math
import sys

#Variable that controls the positions of the potential minima: (+/-) sqrt(1/(2C))
minC = 0.1

#Function to evaluate the double well potential at a point
def potential(E,x):
    C = minC
    x2 = x*x
    x4 = x2*x2
    return E*(C*x4-x2)

#Function that proposes a trial move in x
def trial_move(x,max_disp):
    test_disp = max_disp*(random()-0.5)
    x += test_disp
    return x

#Class for a given layer of the CAPS MC - Has own unique level number, number of MC steps, and potential value
class Layer:
    def __init__(self,num,steps,pot):
        self.layer_num = num                          #Layer number
        self.nsteps = steps                           #Number of MC steps within that layer
        self.pot = pot                                #Coarseness of potential
        self.xs = 2.0                                 #Variable to hold saved coordinate
        self.xt = 2.0                                 #Variable to hold trial coordinate
        self.max_disp = 0.3                           #Maximum random displacement
        self.Es = potential(pot,self.xs)          #Variable to hold potential for xs
        self.Et = 0.0                                 #Variable to hold potential for xt
        self.beta = 1.0                               #Beta temperature param for MC accept
        self.xs_hist = []                             #Array to hold all visited xs
        self.att_count = 0                            #Keep track of attempted MC moves
        self.acc_count = 0                            #Keep track of accepted MC moves

    #Method to run a basic Metropolis MC routine within the layer
    def metropolis(self):
        self.att_count += 1
        self.xt = trial_move(self.xs,self.max_disp)
        self.Et = potential(self.pot,self.xt)
        self.xs_hist.append(self.xs)
#        print 'saved move: '+str(self.xs)
#        print 'saved E: '+str(self.Es)
#        print 'trial move: '+str(self.xt)
#        print 'trial E: '+str(self.Et)
        if self.Et < self.Es:
            self.Es = self.Et
            self.xs = self.xt
            self.acc_count += 1
#            print 'accept'
        else:
            rand_n = random()
            prob = math.exp(-self.beta*(self.Et-self.Es))
            if rand_n < prob:
#                print 'accept'
                self.Es = self.Et
                self.xs = self.xt
                self.acc_count += 1
#            else:
#                print 'reject'

#Class that holds all MC layers of the simulation
class Sim:
    def __init__(self,steps_arr,pot_arr):
        if len(steps_arr) != len(pot_arr):
            print "Layer input is incorrect, exiting..."
            sys.exit()
        else:
            self.steps_arr = steps_arr
            self.pot_arr = pot_arr
            self.num_layers = len(steps_arr)
            self.first_layer = 0
            self.last_layer = self.num_layers-1
            self.layers = []
            for i in range(self.num_layers):
                self.layers.append(Layer(i,steps_arr[i],pot_arr[i]))

    #Method that performs the deltaE1-deltaE0 check between MC layers of simulation
    def metropolis_2(self,xi,xf,poten0,poten1):
        #This can be rewritten to save 2 potential evaluations by storing in self.Es of the layers
        #Just did this because it was the easiest way to do it while debugging the recursion
        beta = 1.0
        E_xf_n1 = potential(poten1,xf)
        E_xi_n1 = potential(poten1,xi)
        E_xf_n0 = potential(poten0,xf)
        E_xi_n0 = potential(poten0,xi)
        deltaE0 = E_xf_n0-E_xi_n0
        deltaE1 = E_xf_n1-E_xi_n1
#        print 'saved x: '+str(xi)
#        print 'trial x: '+str(xf)
#        print 'saved x, E in out layer: '+str(E_xi_n1)
#        print 'saved x, E in in layer: '+str(E_xi_n0)
#        print 'trial x, E in out layer: '+str(E_xf_n1)
#        print 'trial x, E in in layer: '+str(E_xf_n0)
#        print 'layer 1 delta E: '+str(deltaE0)
#        print 'layer 2 delta E: '+str(deltaE1)
#        print 'delta delta E: '+str(deltaE0-deltaE1)
#        if E_xf_n0 < E_xi_n0:
#            print 'accept'
#            E_xi_n0 = E_xf_n0
#            return xf    
        rand_num = random()
        prob = math.exp(-beta*(deltaE0-deltaE1))
#            print rand_num
#            print prob
        if rand_num <= prob:
            E_xi_n0 = E_xf_n0
#                print 'accept'
            return xf
        else:
#                print 'reject'
            return xi

    #Recursive method that runs an arbitrary number of nested loops.  This is where the meat is.
    def run_CAPS(self,level):
        #If there is only one layer, run a normal MC
        if level == 0 and self.last_layer == 0:
            for j in range(self.layers[level].nsteps):                
                print 'iterating in final layer '+str(level)
                self.layers[level].metropolis()            
        #If there are many layers and its the first layer,launch MC and descend to next layer
        elif level == 0 and level != self.last_layer:
            for i in range(self.layers[level].nsteps):
                print 'iteration '+str(i)+' in layer '+str(level)
                self.layers[level+1].xs = self.layers[level].xs
                self.run_CAPS(level+1)
        #If there are many layers and its not the first or last layer
        elif level != 0 and level != self.last_layer:
            for k in range(self.layers[level].nsteps):
                self.layers[level+1].xs = self.layers[level].xs
                self.run_CAPS(level+1)
            xs_0 = self.layers[level-1].xs
            xt_0 = self.layers[level].xs
            poten0 = self.layers[level-1].pot
            poten1 = self.layers[level].pot
            self.layers[level-1].att_count += 1
            self.layers[level-1].xs = self.metropolis_2(xs_0,xt_0,poten0,poten1)
            self.layers[level].xs = self.layers[level-1].xs
            if self.layers[level-1].xs == xt_0:
                self.layers[level-1].acc_count += 1
        #If there are many layers and it is the last layer
        elif level == self.last_layer:
            for j in range(self.layers[level].nsteps):                
                self.layers[level].metropolis()
            xs_0 = self.layers[level-1].xs
            xt_0 = self.layers[level].xs
            poten0 = self.layers[level-1].pot
            poten1 = self.layers[level].pot
            self.layers[level-1].att_count += 1
            self.layers[level-1].xs = self.metropolis_2(xs_0,xt_0,poten0,poten1)
            self.layers[level].xs = self.layers[level-1].xs
            if self.layers[level-1].xs == xt_0:
                self.layers[level-1].acc_count += 1

    def print_acc_ratio(self):
        for layer in self.layers:
            print "Acceptance ratio in layer "+str(layer.layer_num)+": "+str((layer.acc_count)/float(layer.att_count))
