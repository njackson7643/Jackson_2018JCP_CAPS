from CAPS_LJ_def import *

#Parameters for simulation
#step array takes the form [n0steps,n1steps,n2steps,...]
#pot array takes the form [potn0,potn1,potn2,...]
step_arr = [10000,2,10]
pot_arr = [[0.4,2.5],[0.8,2.5],[1.0,2.5]]
#step_arr = [1000000]
#pot_arr = [[0.4,2.5]]


#Run Simulation
#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
mysim = Sim(step_arr,pot_arr,15.0,10,0,0.1,1.0,0.1,1.0)
#Defaults exist. to override enter values here.
mysim.initialize_pinhole()
for i in range(mysim.num_layers):
    mysim.layers[i].xyz = np.copy(mysim.xyz)
#print mysim.layers[0].xyz
mysim.params.max_disp = 0.2
mysim.params.beta = 1.0
mysim.run_CAPS_LJ(0)
mysim.write_xyz(0,'final.xyz')

for i in range(mysim.num_layers):
    print mysim.layers[i].numevals_LJ
    print mysim.layers[i].numevals_soft

#print mysim.layers[0].xyz_hist

#mysim.read_xyz('final.xyz')
#mysim.run_CAPS_LJ(0)

myhist = np
fig,ax1 = plt.subplots()                                                                                  
xmin = 3.0
xmax = 10.0
dx = 0.05
ax=np.arange(xmin,xmax,dx)
plot_ax=np.arange(xmin+dx/2.,xmax-dx/2.,dx)
myhist = np.histogram(np.array(mysim.layers[0].xyz_hist),bins=ax)[0]                                                                                                          
ax1.bar(plot_ax,myhist,dx,alpha=0.7)
plt.xlim(3.0,10.0)
plt.show()                                                                                                          
#mysim.num_layers):                                                                                      

#plt.plot(mysim.layers[0].E_list)
#plt.ylim(min(mysim.layers[0].E_list),0.7*min(mysim.layers[0].E_list))
#plt.show()
"""
#mysim.print_acc_ratio()
print "Simulation Finished"

#Analyze/Plot Simulation results
xmin = 3.0
xmax = 10.0
dx = 0.1
ax = np.arange(xmin,xmax,dx)
plot_ax = np.arange(xmin+dx/2.,xmax-dx/2,dx)
#construct hist
fig,ax1 = plt.subplots()

c_cycle = ['b','g','r','c','m','y','k','w']

for i in range(mysim.num_layers):
#mysim.num_layers):
    myhist = np.histogram(np.array(mysim.layers[i].xyz_hist),bins=ax)[0]
    myhist = myhist/float(np.sum(myhist))
    ax1.bar(plot_ax,myhist,dx,alpha=0.2,color=c_cycle[i],label=str(i)+': '+str(mysim.layers[i].layer_num))
    ax1.set_ylabel('Probability')
    ax1.set_xlabel('Position (x)')
#ax1.legend()
plt.show()

"""
