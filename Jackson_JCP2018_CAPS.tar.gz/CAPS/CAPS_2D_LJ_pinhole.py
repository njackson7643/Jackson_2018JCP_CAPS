from CAPS_2D_LJ_pinhole_def import *
import matplotlib
import pickle

step_arr = [50000,5,5,40]
#step_arr = [10,256]
#pot_arr = [['exact',2.5],['exact',1.15]]
pot_arr = [['exact',10.0],[0.99,10.0],[1.03,10.0],[1.05,10.0]]
#pot_arr = [['exact',2.5],[0.93,2.5],[0.97,2.5],[1.01,2.5]]

#steps_arr,pot_arr,boxl,NA,NB,epsA,sigA,epsB,sigB
#Kob-Anderson parameters: epsAA=1.0,sigAA=1.0,epsAB=1.5,sigAB=0.8,epsBB=0.5,sigBB=0.88
#PIN WIDTH IS LAST ARG
mysim = Sim(step_arr,pot_arr,25.2982213,9,0,1.0,1.0,0.5,0.88,0.75)
#25.2982213 is box length to use for high dens (0.4) results
#29.2119 is box length to use for results data
#ADD FINAL.XYZ TO THE END OF THIS TO LOAD IN AN EQUILIBRATED FILE
#append 'final_save.xyz' at the end of the Sim call to load in pre-equilibrated geometry
#Defaults to arithmetic/geometric mixing, so must set cross-terms directly
#mysim.plot_all_potentials()
#sys.exit()
mysim.params.beta = 1.0

#print 'running simulation'
mysim.run_CAPS_LJ(0)
#print 'simulation over'

mysim.gen_count_FES_surfaces()
mysim.gen_FEP_surface()

#print np.min(mysim.FEP_FES_surf)
FEP_shift = mysim.FEP_FES_surf
#print np.max(FEP_shift)
#FEP_shift -= 5.0
#print minval
#sys.exit()

print(FEP_shift)

minval = 100000.0
for i in range(len(FEP_shift)):
    for j in range(len(FEP_shift)):
        if FEP_shift[i,j] < minval and FEP_shift[i,j] != 0.0:
            minval = FEP_shift[i,j]
        if FEP_shift[i,j] == 0.0:
            FEP_shift[i,j] = -1000.0

FEP_shift -= minval

for i in range(len(FEP_shift)):
    for j in range(len(FEP_shift)):
        if FEP_shift[i,j] == -1000.0-minval:
            FEP_shift[i,j] = float('inf')

#masked_array = np.ma.array(FEP_shift, mask=np.isnan(FEP_shift))
#cmap = matplotlib.cm.viridis
#cmap.set_bad('white',1.)

#print(FEP_shift)
#print(mysim.FES_surfaces[0])

#print minval
#print np.min(FEP_shift)

#ticks = np.linspace(-4.0,3.0,num=6)
ticks = np.arange(-4,4,1)
#print(ticks)

pickle.dump( np.transpose(FEP_shift), open("FEP_shift.p","wb"))
pickle.dump(np.transpose(mysim.FES_surfaces[0]-np.min(mysim.FES_surfaces[0])), open("exact_layer.p","wb"))

fig,ax = plt.subplots(2,sharex=True)

im = ax[0].imshow(np.transpose(FEP_shift),origin='lower',aspect='auto',vmin=0.0,vmax=12.0)
cbar = fig.colorbar(im,ax=ax[0])
cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(),fontsize=12)
im = ax[1].imshow(np.transpose(mysim.FES_surfaces[0]-np.min(mysim.FES_surfaces[0])),origin='lower',aspect='auto',vmin=0.0,vmax=12.0)
cbar = fig.colorbar(im,ax=ax[1])
cbar.ax.set_yticklabels(cbar.ax.get_yticklabels(),fontsize=12)

ax[0].text(-9,60,'A',fontsize=20)
ax[1].text(-9,60,'B',fontsize=20)
ax[0].set_xticklabels(ticks)
ax[1].set_xticklabels(ticks)
ax[1].set_xlabel(r'x ($\sigma$)',fontsize=20)
ax[0].set_yticklabels(ticks)
ax[0].set_ylabel(r'y ($\sigma$)',fontsize=20)
ax[1].set_ylabel(r'y ($\sigma$)',fontsize=20)
ax[1].set_yticklabels(ticks)
ax[0].tick_params(axis='both', which='major', labelsize=14)
ax[1].tick_params(axis='both', which='major', labelsize=14)
plt.tight_layout()
plt.show()

mysim.print_acc_ratio()
mysim.print_pot_calls()
#print "Average energy/particle: "+str(np.mean(np.array(mysim.layers[0].E_list))/256.0)
mysim.write_xyz(0,'final.xyz')


#fig,ax = plt.subplots(2,1)
#ax[0].plot(mysim.layers[0].E_list)
#ax[0].set_ylim(min(mysim.layers[0].E_list),0.0)
#RDF = mysim.RDF_track
#RDF_mean = np.mean(RDF,axis=0)
#r_ax = mysim.RDF_arr
#ax[1].plot(r_ax,RDF_mean,label='CAPS')
#ax[1].axhline(y=1.0,color='r',linestyle='-')
#ax[1].set_xlim(0.0,3.0)
#mysim.write_RDF_file("RDF.txt")
#exact_x,exact_y = mysim.read_RDF_file("exact_1layer_RDF.txt")
#ax[1].plot(exact_x,exact_y,label='1layer exact')
#ax[1].legend()
#plt.show()
